// Motore di gioco: simulazione dei turni, voti, eventi, azioni del giocatore
(function () {
  const D = DATA;
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const it = (n, d = 1) => (n < 0 ? '−' : '') + Math.abs(n).toFixed(d).replace('.', ',');
  const sg = (n, d = 1) => (n < 0 ? '−' : '+') + Math.abs(n).toFixed(d).replace('.', ',');
  const ELEZIONI = [100, 148, 196];

  function rnd(s) {
    s.rng = (s.rng + 0x6D2B79F5) | 0;
    let t = s.rng;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  const zero = () => ({ pil: 0, lav: 0, infl: 0, stab: 0, tes: 0, san: 0, ist: 0, amb: 0, sic: 0, gr: { lav: 0, imp: 0, gio: 0, anz: 0 } });
  function addEff(t, e, k = 1) {
    for (const key in e) {
      if (key === 'gr') for (const g in e.gr) t.gr[g] += e.gr[g] * k;
      else t[key] = (t[key] || 0) + e[key] * k;
    }
  }

  function modsTotali(s) {
    const m = zero();
    s.leggi.inVigore.forEach(id => addEff(m, D.legge(id).eff));
    s.mods.forEach(x => { if (x.fine > s.turno) addEff(m, x.eff); });
    Object.keys(s.diplomazia).forEach(id => {
      const n = s.diplomazia[id];
      if (n.accordo) addEff(m, D.ACCORDO_EFF);
      if (n.patto) addEff(m, D.PATTO_EFF);
    });
    return m;
  }

  const govSeggi = s => s.parlamento.partiti.filter(p => p.governo).reduce((a, p) => a + p.seggi, 0);

  function voto(s, L, neg, bonus = 0) {
    const det = s.parlamento.partiti.map(p => {
      const pd = D.partito(p.id);
      const dot = pd.ideol.reduce((a, v, i) => a + v * L.axes[i], 0);
      const maggioranza = govSeggi(s) >= 101;
      const premioGoverno = p.governo ? (maggioranza ? 0.10 : -0.08) + 0.002 * (s.stabilita - 68) : 0;
      const share = clamp(0.5 + 0.4 * dot + premioGoverno + (neg ? 0.12 : 0) + bonus, 0.03, 0.97);
      return { id: p.id, nome: p.nome, colore: p.colore, tot: p.seggi, si: Math.round(p.seggi * share) };
    });
    const si = det.reduce((a, d) => a + d.si, 0);
    return { si, no: s.parlamento.totale - si, det, ok: si >= 101 };
  }

  function flussoPrevisto(s, m) {
    m = m || modsTotali(s);
    const b = s.budget;
    const entrate = 0.018 * b.tasse * (1 + 0.15 * (s.pil - 0.4));
    const crescita = 1 + 0.0035 * Math.max(0, s.turno - 52); // i costi dello Stato crescono col tempo
    const spese = (0.0042 * b.sociale + 0.003 * b.infra + 0.003 * b.sicurezza + 0.02) * crescita + 0.0006 * s.debito;
    return { entrate, spese, extra: m.tes, saldo: entrate - spese + m.tes };
  }

  // movimento di cassa: se il tesoro scende sotto zero cresce il debito
  function muovi(s, delta) {
    const old = s.tesoro;
    s.tesoro += delta;
    s.debito += 0.3 * (Math.min(0, old) - Math.min(0, s.tesoro));
  }

  function applica(s, e, k = 1) {
    if (!e) return;
    if (e.pil) s.pil += e.pil * k;
    if (e.lav) s.lavoro = clamp(s.lavoro + e.lav * k, 70, 99);
    if (e.infl) s.inflazione = clamp(s.inflazione + e.infl * k, -2, 25);
    if (e.stab) s.stabilita = clamp(s.stabilita + e.stab * k, 0, 100);
    if (e.tes) muovi(s, e.tes * k);
    if (e.gr) for (const g in e.gr) s.gruppi[g] = clamp(s.gruppi[g] + e.gr[g] * k, 0, 100);
    if (e.idx) for (const i in e.idx) s.indici[i] = clamp(s.indici[i] + e.idx[i] * k, 0, 100);
  }

  const NOMI = { pil: 'PIL', lav: 'Occupazione', infl: 'Inflazione', stab: 'Stabilità', tes: 'Tesoro', san: 'Sanità', ist: 'Istruzione', amb: 'Ambiente', sic: 'Sicurezza' };
  function tags(e, opz) {
    opz = opz || {};
    const out = [];
    if (!e) return out;
    ['pil', 'lav', 'infl', 'stab', 'tes', 'san', 'ist', 'amb', 'sic'].forEach(k => {
      if (!e[k]) return;
      const good = k === 'infl' ? e[k] < 0 : e[k] > 0;
      let nome = NOMI[k];
      if (k === 'tes') nome = opz.una ? 'Tesoro' : 'Tesoro/turno';
      const dec = Math.abs(e[k]) >= 5 ? 0 : (Math.abs(e[k]) >= 1 ? 1 : 2);
      out.push({ t: `${nome} ${sg(e[k], dec)}`, good });
    });
    if (e.idx) for (const i in e.idx) out.push({ t: `${i[0].toUpperCase() + i.slice(1)} ${sg(e.idx[i], 0)}`, good: e.idx[i] > 0 });
    if (e.gr) for (const g in e.gr) if (e.gr[g]) out.push({ t: `${D.GRUPPI[g]} ${sg(e.gr[g], 0)}`, good: e.gr[g] > 0 });
    return out;
  }

  function log(s, titolo, tipo, thumb, extra) {
    s.registro.unshift(Object.assign({ turno: s.turno, titolo, tipo, thumb }, extra || {}));
    if (s.registro.length > 40) s.registro.length = 40;
  }

  // ---- priorità del turno ----
  const inV = (s, id) => s.leggi.inVigore.includes(id);
  const evAtt = (s, id) => s.eventi.some(e => e.id === id);
  const CAND = [
    { id: 'fiscale', titolo: 'Riforma fiscale', sez: 'leggi', urg: 1, attiva: s => !inV(s, 'riforma-fiscale'), fatto: s => inV(s, 'riforma-fiscale') },
    { id: 'infra', titolo: 'Piano infrastrutture', sez: 'leggi', urg: 1, attiva: s => !inV(s, 'infrastrutture'), fatto: s => inV(s, 'infrastrutture') },
    { id: 'proteste', titolo: 'Gestione proteste', sez: 'eventi', urg: 3, attiva: s => evAtt(s, 'proteste') || evAtt(s, 'sciopero'), fatto: s => !evAtt(s, 'proteste') && !evAtt(s, 'sciopero') },
    { id: 'infl', titolo: 'Contenere l\'inflazione', sez: 'economia', urg: 2, attiva: s => s.inflazione > 3, fatto: s => s.inflazione <= 2.6 },
    { id: 'tesoro', titolo: 'Risanare il tesoro', sez: 'economia', urg: 2, attiva: s => s.tesoro < 2, fatto: s => s.tesoro >= 4 },
    { id: 'consenso', titolo: 'Recuperare consenso', sez: 'societa', urg: 2, attiva: s => s.consenso < 46, fatto: s => s.consenso >= 52 },
    { id: 'lavoro', titolo: 'Sostenere l\'occupazione', sez: 'leggi', urg: 2, attiva: s => s.lavoro < 91, fatto: s => s.lavoro >= 92 },
    { id: 'stab', titolo: 'Rafforzare la stabilità', sez: 'governo', urg: 2, attiva: s => s.stabilita < 50, fatto: s => s.stabilita >= 58 },
    { id: 'debito', titolo: 'Ridurre il debito', sez: 'economia', urg: 1, attiva: s => s.debito > 90, fatto: s => s.debito <= 80 },
    { id: 'eventi', titolo: 'Rispondere agli eventi', sez: 'eventi', urg: 1, attiva: s => s.eventi.length >= 2, fatto: s => s.eventi.length === 0 },
    { id: 'sanita', titolo: 'Migliorare la sanità', sez: 'leggi', urg: 1, attiva: s => s.indici.sanita < 55, fatto: s => s.indici.sanita >= 62 },
    { id: 'ambiente', titolo: 'Proteggere l\'ambiente', sez: 'leggi', urg: 1, attiva: s => s.indici.ambiente < 48, fatto: s => s.indici.ambiente >= 56 }
  ];
  const cand = id => CAND.find(c => c.id === id);

  function prioritaView(s) {
    const lista = s.priorita.map(p => {
      const c = cand(p.id);
      return { id: p.id, titolo: c.titolo, sez: c.sez, fatto: c.fatto(s), urg: c.urg };
    });
    let focus = -1, best = 0;
    lista.forEach((p, i) => { if (!p.fatto && p.urg > best) { best = p.urg; focus = i; } });
    lista.forEach((p, i) => { p.focus = i === focus; });
    return lista;
  }

  function aggiornaPriorita(s) {
    s.priorita.forEach(p => {
      const c = cand(p.id);
      if (c.fatto(s)) { if (p.fattoDa == null) p.fattoDa = s.turno; } else p.fattoDa = null;
    });
    s.priorita = s.priorita.filter(p => !(p.fattoDa != null && p.fattoDa < s.turno));
    CAND.forEach(c => {
      if (s.priorita.length < 3 && !s.priorita.some(p => p.id === c.id) && c.attiva(s) && !c.fatto(s)) s.priorita.push({ id: c.id, fattoDa: null });
    });
  }

  // ---- azioni del giocatore ----
  const err = m => ({ ok: false, msg: m });
  const ok = m => ({ ok: true, msg: m });

  function proponi(id) {
    const s = State, L = D.legge(id);
    if (s.fine) return err('La partita è finita.');
    if (s.leggi.inVigore.includes(id)) return err('Questa legge è già in vigore.');
    if (s.leggi.inDiscussione.some(d => d.id === id)) return err('Già in discussione.');
    if (s.leggi.inDiscussione.length >= 3) return err('Al massimo tre leggi in discussione.');
    if ((s.leggi.bloccate[id] || 0) > s.turno) return err('Respinta da poco: riprova tra ' + (s.leggi.bloccate[id] - s.turno) + ' turni.');
    if (s.tesoro < L.costo) return err('Tesoro insufficiente.');
    s.leggi.inDiscussione.push({ id, neg: false, fase: 'commissione', avanzamento: 0, emendamento: null, camera: null, senato: null, bonus: 0 });
    return ok('«' + L.nome + '» è stata depositata e assegnata alla commissione competente.');
  }
  function ritira(id) {
    const s = State;
    s.leggi.inDiscussione = s.leggi.inDiscussione.filter(d => d.id !== id);
    return ok('Proposta ritirata.');
  }
  function negozia(id) {
    const s = State, d = s.leggi.inDiscussione.find(x => x.id === id);
    if (!d || d.neg) return err('Già negoziata.');
    if (s.tesoro < 0.3) return err('Tesoro insufficiente.');
    muovi(s, -0.3);
    d.neg = true;
    return ok('Compromesso trovato: più voti favorevoli.');
  }
  function decidiEmendamento(id, scelta) {
    const s=State, d=s.leggi.inDiscussione.find(x=>x.id===id);
    if(!d||!d.emendamento||d.emendamento.stato!=='Proposto')return err('Nessun emendamento da decidere.');
    if(scelta==='accogli'){d.emendamento.stato='Accolto';d.bonus=0.035;log(s,'Accolto emendamento dell’opposizione alla legge '+D.legge(id).nome,'neu','legge');return ok('Emendamento accolto: la proposta ottiene un piccolo vantaggio negoziale.');}
    d.emendamento.stato='Respinto';d.bonus=-0.015;log(s,'Respinto emendamento dell’opposizione alla legge '+D.legge(id).nome,'neg','legge');return ok('Emendamento respinto: aumentano le tensioni sul provvedimento.');
  }
  function votaCamera(id) {
    const s=State,d=s.leggi.inDiscussione.find(x=>x.id===id);
    if(!d||d.fase!=='camera')return err('La legge non è pronta per il voto della Camera.');
    const L=D.legge(id),v=voto(s,L,d.neg,Number(d.bonus||0));
    d.camera={si:v.si,no:v.no,ok:v.ok,turno:s.turno};
    s.leggi.storicoVoti.unshift({turno:s.turno,nome:L.nome,fase:'Camera',camera:true,si:v.si,no:v.no,ok:v.ok});
    if(v.ok){d.fase='senato';log(s,L.nome+' approvata alla Camera ('+v.si+'–'+v.no+')','pos','legge');return ok('Camera: approvata. Il testo passa al Senato.');}
    d.fase='respinta';s.leggi.bloccate[id]=s.turno+8;s.stabilita=clamp(s.stabilita-1,0,100);log(s,L.nome+' respinta alla Camera','neg','legge');return ok('Camera: il disegno di legge è respinto.');
  }
  function votaSenato(id) {
    const s=State,d=s.leggi.inDiscussione.find(x=>x.id===id);
    if(!d||d.fase!=='senato')return err('La legge non è pronta per il voto del Senato.');
    const L=D.legge(id),v=voto(s,L,d.neg,Number(d.bonus||0));
    const si=Math.round(v.si/2),no=100-si,okV=si>=51;
    d.senato={si,no,ok:okV,turno:s.turno};
    s.leggi.storicoVoti.unshift({turno:s.turno,nome:L.nome,fase:'Senato',senato:true,si,no,ok:okV});
    if(okV){d.fase='promulgazione';log(s,L.nome+' approvata dal Senato ('+si+'–'+no+')','pos','legge');return ok('Senato: approvata. La legge attende la promulgazione del Re.');}
    d.fase='respinta';s.leggi.bloccate[id]=s.turno+8;s.stabilita=clamp(s.stabilita-1,0,100);log(s,L.nome+' respinta dal Senato','neg','legge');return ok('Senato: il disegno di legge è respinto.');
  }
  function promulga(id) {
    const s=State,d=s.leggi.inDiscussione.find(x=>x.id===id);
    if(!d||d.fase!=='promulgazione')return err('La legge non è pronta per la promulgazione.');
    const L=D.legge(id);if(s.tesoro<L.costo)return err('Tesoro insufficiente per rendere operativa la legge.');
    muovi(s,-L.costo);s.leggi.inVigore.push(id);s.leggi.inDiscussione=s.leggi.inDiscussione.filter(x=>x.id!==id);
    s.stabilita=clamp(s.stabilita+1,0,100);s.consenso=clamp(s.consenso+0.5,0,100);
    s.leggi.storicoVoti.unshift({turno:s.turno,nome:L.nome,fase:'Promulgazione regia',promulgata:true,ok:true,si:d.senato.si,no:d.senato.no});
    log(s,L.nome+' promulgata ed entrata in vigore','pos','legge');return ok('Legge promulgata: gli effetti entrano in vigore dal prossimo turno.');
  }
  function abroga(id) {
    const s = State;
    if (!s.leggi.inVigore.includes(id)) return err('Non in vigore.');
    s.leggi.inVigore = s.leggi.inVigore.filter(x => x !== id);
    s.stabilita = clamp(s.stabilita - 2, 0, 100);
    log(s, D.legge(id).nome + ' abrogata', 'neu', 'legge');
    return ok('Legge abrogata.');
  }
  function scegli(uid, idx) {
    const s = State, ev = s.eventi.find(e => e.uid === uid);
    if (!ev) return err('Evento non trovato.');
    const def = D.evento(ev.id), sc = def.scelte[idx];
    if (sc.costo && s.tesoro < sc.costo) return err('Tesoro insufficiente.');
    risolvi(s, ev, def, sc);
    return ok(sc.t);
  }
  function risolvi(s, ev, def, sc) {
    if (sc.costo) muovi(s, -sc.costo);
    applica(s, sc.i);
    if (sc.mod) s.mods.push({ fine: s.turno + sc.mod.turni, nome: sc.mod.nome, eff: sc.mod.eff });
    if (sc.rel) s.diplomazia[sc.rel[0]].rel = clamp(s.diplomazia[sc.rel[0]].rel + sc.rel[1], 0, 100);
    if (sc.relMin) {
      const ids = Object.keys(s.diplomazia).sort((a, b) => s.diplomazia[a].rel - s.diplomazia[b].rel);
      s.diplomazia[ids[0]].rel = clamp(s.diplomazia[ids[0]].rel + sc.relMin, 0, 100);
    }
    s.eventi = s.eventi.filter(e => e.uid !== ev.uid);
    const r = s.registro.find(x => x.uid === ev.uid);
    if (r) r.esito = sc.t;
  }
  function setBudget(k, v) {
    State.budget[k] = clamp(Math.round(v), k === 'tasse' ? 20 : 0, k === 'tasse' ? 48 : 100);
    return ok('');
  }
  function rimborsa() {
    const s = State;
    if (s.tesoro < 1) return err('Servono almeno 1 mld in cassa.');
    if (s.debito <= 0) return err('Nessun debito da rimborsare.');
    s.tesoro -= 1;
    s.debito = Math.max(0, s.debito - 0.35);
    return ok('Rimborsato 1 mld di debito.');
  }
  function direttiva(id) {
    const s = State, m = D.ministro(id), d = m.dir;
    const assegnato=(s.incarichi||{})[id];
    if(!assegnato)return err('Ministero vacante: nomina prima un nuovo titolare.');
    const persona=D.ministro(assegnato)||m;
    if ((s.dir[id] || 0) > s.turno) return err('Disponibile tra ' + (s.dir[id] - s.turno) + ' turni.');
    if (d.costo && s.tesoro < d.costo) return err('Tesoro insufficiente.');
    const k = persona.comp / 75;
    const fid=Number(s.ministri?.fiducia?.[assegnato]??70);
    if(fid<25)return err('Il ministro è in rotta con il Governo: devi prima ricucire il rapporto o sostituirlo.');
    if (d.costo) muovi(s, -d.costo);
    applica(s, d.i, k);
    if (d.mod) {
      const eff = {};
      for (const key in d.mod.eff) eff[key] = d.mod.eff[key] * k;
      s.mods.push({ fine: s.turno + d.mod.turni, nome: d.mod.nome, eff });
    }
    s.dir[id] = s.turno + d.cd;
    return ok(d.nome + ' eseguita.');
  }
  function rimpasto(incarico, personaId) {
    const s=State, ruoli=D.CONSIGLIO, persona=D.ministro(personaId);
    if(!ruoli.some(x=>x.id===incarico)||!persona)return err('Incarico o ministro non valido.');
    if(!s.parlamento.partiti.some(p=>p.governo))return err('Non esiste un Governo in carica.');
    const incarichi=s.incarichi||(s.incarichi={});
    const precedente=incarichi[incarico]||incarico;
    const altro=Object.keys(incarichi).find(k=>incarichi[k]===personaId&&k!==incarico);
    if(precedente===personaId)return err('Il ministro ricopre già questo incarico.');
    if(altro)incarichi[altro]=precedente||null;
    incarichi[incarico]=personaId;
    s.ministri.fiducia[personaId]=clamp(Number(s.ministri.fiducia[personaId]??65)+3,0,100);
    s.stabilita=clamp(s.stabilita-0.7,0,100);
    const pol=s.politica||{};
    ['verdi','blu'].forEach(id=>{if(s.parlamento.partiti.some(x=>x.id===id&&x.governo))pol.fiducia[id]=clamp(Number(pol.fiducia?.[id]??68)-1,0,100);});
    log(s,'Rimpasto: '+personaId+' assume il ministero al posto di '+precedente,'neu','legge');
    return ok('Rimpasto effettuato. Gli incarichi sono stati aggiornati.');
  }

  function negoziaProgramma(partito, tema) {
    const s=State, pol=s.politica||{}, p=s.parlamento.partiti.find(x=>x.id===partito&&x.governo);
    if(!p)return err('Puoi negoziare il programma solo con un partito della maggioranza.');
    const prog=s.programma||(s.programma={accordi:[],ultimaTrattativa:0});
    if(s.turno-(prog.ultimaTrattativa||0)<4)return err('Una trattativa programmatica ogni 4 turni.');
    const temi={
      sociale:{nome:'Patto sociale',eff:{gr:{lav:2,anz:2}},costo:0.7},
      crescita:{nome:'Patto per la crescita',eff:{pil:0.06,gr:{imp:2}},costo:0.5},
      ambiente:{nome:'Patto verde',eff:{idx:{ambiente:3},gr:{gio:2}},costo:0.6}
    };
    const x=temi[tema];if(!x)return err('Tema non riconosciuto.');
    if(s.tesoro<x.costo)return err('Tesoro insufficiente per finanziare il patto.');
    muovi(s,-x.costo);applica(s,x.eff);
    pol.fiducia[partito]=clamp(Number(pol.fiducia?.[partito]??68)+5,0,100);
    prog.accordi.unshift({turno:s.turno,partito,nome:p.nome,tema:x.nome});
    prog.accordi=prog.accordi.slice(0,8);prog.ultimaTrattativa=s.turno;
    log(s,'Accordo di maggioranza: '+x.nome+' con '+p.nome,'pos','legge');
    return ok('Patto programmatico firmato con '+p.nome+'.');
  }

  function gestisciScandalo(azione) {
    const s=State, m=s.ministri?.scandalo;
    if(!m)return err('Non ci sono scandali ministeriali da gestire.');
    const fid=s.ministri.fiducia[m.ministro]??60;
    if(azione==='difendi'){
      s.ministri.fiducia[m.ministro]=clamp(fid+8,0,100);
      s.consenso=clamp(s.consenso-2,0,100);s.stabilita=clamp(s.stabilita-1,0,100);
      log(s,'Il Governo difende '+m.nome+' nonostante le accuse','neg','proteste');
      m.stato='Difeso';
      return ok('Hai difeso il ministro: la sua lealtà cresce, ma il Governo paga un costo d’immagine.');
    }
    if(azione==='indaga'){
      s.ministri.fiducia[m.ministro]=clamp(fid-8,0,100);
      s.consenso=clamp(s.consenso+1,0,100);s.stabilita=clamp(s.stabilita+0.5,0,100);
      m.stato='Indagine aperta';
      log(s,'Il Governo dispone un’indagine indipendente su '+m.nome,'neu','legge');
      return ok('Indagine indipendente avviata. Il ministro resta in carica durante gli accertamenti.');
    }
    if(azione==='rimuovi'){
      const incarico=Object.keys(s.incarichi||{}).find(k=>s.incarichi[k]===m.ministro);
      if(incarico)s.incarichi[incarico]=null;
      s.ministri.dimissioni.unshift({turno:s.turno,ministro:m.ministro,nome:m.nome,causa:'Scandalo'});
      s.ministri.fiducia[m.ministro]=0;
      s.consenso=clamp(s.consenso+2,0,100);s.stabilita=clamp(s.stabilita-1.5,0,100);
      log(s,m.nome+' viene rimosso dopo lo scandalo','neu','legge');
      m.stato='Rimosso';
      return ok('Ministro rimosso. Nomina un sostituto dal menu del ministero rimasto vacante.');
    }
    return err('Azione non riconosciuta.');
  }

  function nominaMinistro(incarico, personaId) {
    const s=State, ruolo=D.CONSIGLIO.find(x=>x.id===incarico), persona=D.ministro(personaId);
    if(!ruolo||!persona)return err('Incarico o candidato non valido.');
    const occupato=Object.keys(s.incarichi||{}).some(k=>s.incarichi[k]===personaId&&k!==incarico);
    if(occupato)return err('Il candidato ricopre già un altro ministero.');
    const precedente=s.incarichi[incarico];
    if(precedente===personaId)return err('Questo ministro è già in carica.');
    s.incarichi[incarico]=personaId;
    if(s.ministri.dimissioni.some(x=>x.ministro===personaId))s.ministri.dimissioni=s.ministri.dimissioni.filter(x=>x.ministro!==personaId);
    s.ministri.fiducia[personaId]=clamp(Number(s.ministri.fiducia[personaId]??65)+5,0,100);
    s.stabilita=clamp(s.stabilita-0.4,0,100);
    log(s,'Nomina di '+personaId+' al ministero '+incarico,'pos','legge');
    return ok('Nomina completata.');
  }

  function diplo(id, az) {
    const s = State, n = s.diplomazia[id], N = D.NAZIONI.find(x => x.id === id);
    if (az === 'missione') {
      if (s.turno - n.ultima < 3) return err('Una missione ogni 3 turni.');
      if (s.tesoro < 0.2) return err('Tesoro insufficiente.');
      muovi(s, -0.2); n.rel = clamp(n.rel + 6, 0, 100); n.ultima = s.turno;
      return ok('Relazioni con ' + N.nome + ' migliorate.');
    }
    if (az === 'accordo') {
      if (n.accordo) return err('Accordo già firmato.');
      if (n.rel < 55) return err('Servono relazioni di almeno 55.');
      if (s.tesoro < 0.5) return err('Tesoro insufficiente.');
      muovi(s, -0.5); n.accordo = true;
      log(s, 'Accordo commerciale con ' + N.nome, 'pos', 'accordo');
      return ok('Accordo firmato.');
    }
    if (az === 'patto') {
      if (n.patto) return err('Patto già firmato.');
      if (n.rel < 65) return err('Servono relazioni di almeno 65.');
      if (s.tesoro < 0.8) return err('Tesoro insufficiente.');
      muovi(s, -0.8); n.patto = true;
      if (id !== 'karvia') s.diplomazia.karvia.rel = clamp(s.diplomazia.karvia.rel - 5, 0, 100);
      log(s, 'Patto di difesa con ' + N.nome, 'pos', 'militare');
      return ok('Patto firmato.');
    }
    return err('Azione sconosciuta.');
  }

  // ---- elezioni ----
  function elezioni(s) {
    // Le intenzioni di voto entrano nel risultato: le campagne possono spostare
    // sia la quota complessiva della coalizione sia gli equilibri tra i partner.
    rilevaSondaggi(s,true);
    const sondaggio=Number(s.sondaggi?.governo??s.consenso);
    const share = clamp(0.5 + (sondaggio - 50) * 0.006 + (s.stabilita - 60) * 0.0015 + (rnd(s) - 0.5) * 0.035, 0.34, 0.66);
    const gov = Math.round(200 * share);
    const opp = 200 - gov;
    const pv=Number(s.sondaggi?.partiti?.verdi??31), pb=Number(s.sondaggi?.partiti?.blu??30);
    const rv = clamp(pv/Math.max(1,pv+pb), 0.35, 0.65);
    const P = id => s.parlamento.partiti.find(p => p.id === id);
    const verdi = Math.round(gov * rv);
    P('verdi').seggi = verdi; P('blu').seggi = gov - verdi;
    const ind = Math.max(2, Math.round(opp * 0.05));
    const gialli = Math.round((opp - ind) * (0.25 + (s.gruppi.anz < 50 ? 0.05 : 0)));
    P('ind').seggi = ind; P('gialli').seggi = gialli; P('rossi').seggi = opp - ind - gialli;
    const precedenti=s.parlamento.partiti.filter(p=>p.governo).map(p=>p.id);
    s.parlamento.partiti.forEach(p=>p.governo=false);
    const verdiP=P('verdi'), bluP=P('blu');
    if(verdiP)verdiP.governo=true; if(bluP)bluP.governo=true;
    if(govSeggi(s)<101){
      const candidati=s.parlamento.partiti.filter(p=>!p.governo).sort((a,b)=>((precedenti.includes(b.id)?1:0)-(precedenti.includes(a.id)?1:0)) || b.seggi-a.seggi);
      for(const p of candidati){if(govSeggi(s)>=101)break;p.governo=true;}
    }
    return { gov:govSeggi(s), opp:200-govSeggi(s), verdi, blu:gov-verdi, seggiEletti:gov };
  }

  function punteggio(s) {
    const econ = 0.5 * clamp((s.lavoro - 85) * 8, 0, 100) + 0.5 * clamp(100 - (s.debito - 40) * 1.2, 0, 100);
    return Math.round(0.3 * s.consenso + 0.3 * s.stabilita + 0.4 * econ);
  }
  function giudizio(p) {
    return p >= 75 ? 'Età dell\'oro' : p >= 62 ? 'Regno prospero' : p >= 48 ? 'Regno in equilibrio' : 'Regno sopravvissuto a fatica';
  }

  function controllaFine(s) {
    if (s.consenso <= 10) return { esito: 'sconfitta', titolo: 'Rivolta popolare', testo: 'Il popolo ha perso ogni fiducia: le piazze insorgono e il governo cade.' };
    if (s.stabilita <= 10) return { esito: 'sconfitta', titolo: 'Crollo istituzionale', testo: 'Le istituzioni non reggono più: il regno precipita nel caos.' };
    if (s.debito >= 150) return { esito: 'sconfitta', titolo: 'Bancarotta', testo: 'Il debito è insostenibile: i creditori chiudono i rubinetti e il regno è insolvente.' };
    if (s.negStreak >= 12) return { esito: 'sconfitta', titolo: 'Default dello Stato', testo: 'Le casse sono vuote da troppo tempo: lo Stato non può più pagare stipendi e fornitori.' };
    if (s.turno >= s.turniTotali) {
      const p = punteggio(s);
      return { esito: 'vittoria', titolo: giudizio(p), testo: 'Hai guidato il regno fino al turno ' + s.turniTotali + ' mantenendolo in equilibrio.', punteggio: p };
    }
    return null;
  }

  function pescaEvento(s) {
    if (s.eventi.length >= 4 || rnd(s) > 0.42) return null;
    const c = D.EVENTI.filter(e => !evAtt(s, e.id) && s.turno - (s.ultimoEvento[e.id] ?? -99) >= 14)
      .map(e => [e, Math.max(0, e.peso(s))]).filter(x => x[1] > 0);
    const tot = c.reduce((a, x) => a + x[1], 0);
    if (!tot) return null;
    let r = rnd(s) * tot;
    for (const [e, w] of c) { r -= w; if (r <= 0) return e; }
    return c[c.length - 1][0];
  }

  // ---- dinamiche politiche autonome (richieste della coalizione e pressione dell'opposizione) ----
  const TEMI_PARTNER = {
    verdi: [{tema:'transizione energetica',testo:'accelerare gli investimenti nelle energie rinnovabili',eff:{pil:0.04,idx:{ambiente:2},gr:{gio:2}}},{tema:'tutela ambientale',testo:'rafforzare i controlli ambientali e la tutela del territorio',eff:{idx:{ambiente:3},gr:{gio:1}}}],
    blu: [{tema:'imprese e infrastrutture',testo:'rafforzare gli incentivi alle imprese e i cantieri strategici',eff:{pil:0.08,lav:0.15,gr:{imp:2}}},{tema:'sicurezza',testo:'aumentare le risorse per sicurezza e presidio del territorio',eff:{stab:1.5,idx:{sicurezza:2},gr:{anz:1}}}]
  };
  function politicaAutonoma(s, rep) {
    const pol=s.politica||(s.politica={fiducia:{verdi:68,blu:68},richieste:[],opposizione:{pressione:0,iniziative:0,ultimaIniziativa:0},crisi:null,storico:[]});
    if(s.turno%4!==0)return;
    // Le richieste dei partner nascono dai loro interessi e dalla fiducia nel Governo.
    const partner=['verdi','blu'].filter(id=>s.parlamento.partiti.some(p=>p.id===id&&p.governo));
    partner.forEach(id=>{
      const trust=Number(pol.fiducia[id]??68), pending=pol.richieste.some(r=>r.partito===id&&r.stato==='In attesa');
      if(!pending&&trust<82&&((s.turno+ (id==='verdi'?1:3))%8===0)){
        const pool=TEMI_PARTNER[id], choice=pool[(Math.floor(s.turno/8)+(id==='blu'?1:0))%pool.length];
        const req={id:'req-'+s.turno+'-'+id,partito:id,nome:id==='verdi'?'Verdi':'Blu',tema:choice.tema,testo:choice.testo,eff:choice.eff,turno:s.turno,stato:'In attesa',scadenza:s.turno+8};
        pol.richieste.unshift(req); rep.avvisi.push(req.nome+' chiede al Governo di '+req.testo+'.');
        log(s,req.nome+' presenta una richiesta politica: '+req.tema,'neu','legge');
      }
    });
    // Pressione pubblica e iniziative autonome dell'opposizione.
    const stress=(s.consenso<42?1:0)+(s.stabilita<48?1:0)+(s.lavoro<88?1:0)+(s.inflazione>4?1:0)+(govSeggi(s)<101?2:0);
    if(stress>=2){
      pol.opposizione.pressione=clamp(pol.opposizione.pressione+1,0,10);
      s.stabilita=clamp(s.stabilita-0.45,0,100);
      if(pol.opposizione.pressione>=3&&s.turno-pol.opposizione.ultimaIniziativa>=8){
        pol.opposizione.iniziative++;pol.opposizione.ultimaIniziativa=s.turno;
        const temi=['un piano straordinario per il lavoro','un’inchiesta sui costi della spesa pubblica','un pacchetto urgente per sanità e territori','una revisione della politica fiscale'];
        const tema=temi[(pol.opposizione.iniziative-1)%temi.length];
        pol.opposizione.ultimaProposta={turno:s.turno,tema,stato:'Presentata'};
        rep.avvisi.push('L’opposizione presenta un’iniziativa autonoma: '+tema+'.');
        log(s,'L’opposizione presenta '+tema,'neg','proteste');
      }
    } else pol.opposizione.pressione=Math.max(0,pol.opposizione.pressione-1);
    // Una mozione di sfiducia può nascere solo durante una crisi politica concreta.
    const crisi=(s.stabilita<38?1:0)+(s.consenso<34?1:0)+(govSeggi(s)<101?2:0)+(['verdi','blu'].some(id=>Number(pol.fiducia[id]??68)<30)?1:0)+(pol.opposizione.pressione>=7?1:0);
    if((!pol.mozione || pol.mozione.stato!=='Da votare') && crisi>=3 && s.turno-(pol.ultimaMozione||0)>=12){
      if(pol.mozione){pol.storicoMozioni=pol.storicoMozioni||[];pol.storicoMozioni.unshift(Object.assign({},pol.mozione));pol.storicoMozioni=pol.storicoMozioni.slice(0,5);}
      pol.mozione={turno:s.turno,proponente:'Rossi',motivo:govSeggi(s)<101?'perdita della maggioranza parlamentare':'grave crisi di fiducia e stabilità',stato:'Da votare'};
      pol.ultimaMozione=s.turno;
      rep.avvisi.push('L’opposizione deposita una mozione di sfiducia: il Governo deve affrontare il voto parlamentare.');
      log(s,'Deposita una mozione di sfiducia contro il Governo','neg','proteste');
    }
    // Una richiesta ignorata indebolisce gradualmente la fiducia.
    pol.richieste.forEach(r=>{if(r.stato==='In attesa'&&s.turno>=r.scadenza){r.stato='Ignorata';pol.fiducia[r.partito]=clamp(Number(pol.fiducia[r.partito]??68)-7,0,100);log(s,r.nome+' considera ignorata la propria richiesta','neg','proteste');}});
    pol.richieste=pol.richieste.slice(0,12);
    ['verdi','blu'].forEach(id=>{if(Number(pol.fiducia[id]??68)<25&&partner.includes(id)){pol.crisi=id;}});
    if(pol.crisi){const party=s.parlamento.partiti.find(p=>p.id===pol.crisi);if(party&&party.governo){party.governo=false;pol.fiducia[pol.crisi]=Math.max(0,Number(pol.fiducia[pol.crisi]??25)-5);rep.avvisi.push('Crisi di coalizione: '+party.nome+' abbandona il Governo.');log(s,party.nome+' lascia la coalizione','neg','proteste');}pol.crisi=null;}
  }
  function votaSfiducia() {
    const s=State, pol=s.politica, m=pol&&pol.mozione;
    if(!m||m.stato!=='Da votare')return err('Non ci sono mozioni di sfiducia da votare.');
    const opposizione=s.parlamento.partiti.filter(p=>!p.governo).reduce((a,p)=>a+p.seggi,0);
    const dissidenti=s.parlamento.partiti.filter(p=>p.governo).reduce((a,p)=>{
      const fiducia=Number(pol.fiducia?.[p.id]??68);
      return a+Math.round(p.seggi*clamp((48-fiducia)/100,0,0.32));
    },0);
    const pressione=Math.round((Number(pol.opposizione?.pressione||0)-4)*1.2);
    const si=clamp(opposizione+dissidenti+pressione,0,s.parlamento.totale);
    const no=s.parlamento.totale-si, passa=si>=101;
    m.stato=passa?'Approvata':'Respinta';m.si=si;m.no=no;m.esitoTurno=s.turno;
    s.leggi.storicoVoti.unshift({turno:s.turno,nome:'Mozione di sfiducia',fase:'Mozione parlamentare',si,no,ok:passa});
    if(passa){
      s.politica.crisiGoverno={turno:s.turno,si,no,stato:'consultazioni',partnerPrecedenti:s.parlamento.partiti.filter(p=>p.governo).map(p=>p.id)};
      s.parlamento.partiti.forEach(p=>{p.governo=false;});
      s.stabilita=clamp(s.stabilita-5,0,100);
      log(s,'Il Parlamento approva la mozione di sfiducia ('+si+'–'+no+'): si aprono le consultazioni','neg','proteste');
      return ok('Mozione approvata: il Governo è caduto. Ora devi trovare una nuova maggioranza o convocare elezioni.');
    }
    pol.opposizione.pressione=clamp(pol.opposizione.pressione-2,0,10);
    s.stabilita=clamp(s.stabilita+2,0,100);
    log(s,'Il Governo supera la mozione di sfiducia ('+si+'–'+no+')','pos','legge');
    return ok('Mozione respinta: il Governo resta in carica e rafforza temporaneamente la propria posizione.');
  }

  function formaGoverno(scelta) {
    const s=State, pol=s.politica||{};
    if(!pol.crisiGoverno)return err('Non ci sono consultazioni in corso.');
    const P=id=>s.parlamento.partiti.find(p=>p.id===id);
    const parties=s.parlamento.partiti;
    if(scelta==='compromesso'){
      const ordine=['verdi','blu','gialli','ind','rossi'];
      let scelti=[];
      // Si parte dai partner con maggiore fiducia e si aggiungono gruppi fino alla maggioranza.
      const candidati=ordine.map(id=>P(id)).filter(Boolean).sort((a,b)=>{
        const precedenti=pol.crisiGoverno.partnerPrecedenti||[];
        const score=p=>(pol.fiducia?.[p.id]??(precedenti.includes(p.id)?55:35))+(precedenti.includes(p.id)?18:0);
        return score(b)-score(a);
      });
      let seggi=0;
      for(const p of candidati){if(seggi>=101)break;scelti.push(p);seggi+=p.seggi;}
      if(seggi<101)return err('Nessuna maggioranza praticabile: valuta un Governo di unità nazionale o elezioni.');
      parties.forEach(p=>p.governo=scelti.includes(p));
      s.stabilita=clamp(s.stabilita+3,0,100);
      s.consenso=clamp(s.consenso+1,0,100);
      log(s,'Nasce un Governo di compromesso con '+scelti.map(p=>p.nome).join(', '),'pos','legge');
    }else if(scelta==='unita'){
      parties.forEach(p=>p.governo=true);
      s.stabilita=clamp(s.stabilita+6,0,100);
      s.consenso=clamp(s.consenso-2,0,100);
      log(s,'Nasce un Governo di unità nazionale con tutti i gruppi parlamentari','neu','legge');
    }else if(scelta==='elezioni'){
      const esito=elezioni(s);
      s.stabilita=clamp(s.stabilita-2,0,100);
      s.consenso=clamp(s.consenso+1,0,100);
      log(s,'Elezioni anticipate: nuova maggioranza di '+govSeggi(s)+' seggi','neu','festa');
    }else return err('Scelta non riconosciuta.');
    pol.crisiGoverno=null;
    pol.mozione=null;
    pol.opposizione.pressione=0;
    ['verdi','blu'].forEach(id=>{pol.fiducia[id]=clamp(Number(pol.fiducia?.[id]??55)+8,0,100);});
    return ok('Nuovo Governo insediato: '+govSeggi(s)+' seggi di maggioranza. La legislatura continua.');
  }

  function decisionePolitica(id, scelta) {
    const s=State, pol=s.politica, r=pol&&pol.richieste.find(x=>x.id===id&&x.stato==='In attesa');
    if(!r)return err('Questa richiesta non è più disponibile.');
    if(scelta==='accogli'){
      applica(s,r.eff||{});pol.fiducia[r.partito]=clamp(Number(pol.fiducia[r.partito]??68)+7,0,100);r.stato='Accolta';
      log(s,'Il Governo accoglie la richiesta dei '+r.nome,'pos','legge');
      return ok('Richiesta accolta: la fiducia del partner aumenta.');
    }
    if(scelta==='negozia'){
      pol.fiducia[r.partito]=clamp(Number(pol.fiducia[r.partito]??68)+3,0,100);s.stabilita=clamp(s.stabilita+0.5,0,100);r.stato='Compromesso';
      log(s,'Il Governo trova un compromesso con '+r.nome,'neu','legge');
      return ok('Compromesso raggiunto: il partner mantiene il sostegno.');
    }
    pol.fiducia[r.partito]=clamp(Number(pol.fiducia[r.partito]??68)-5,0,100);r.stato='Respinta';
    log(s,'Il Governo respinge la richiesta dei '+r.nome,'neg','proteste');
    return ok('Richiesta respinta: la fiducia del partner diminuisce.');
  }


  function rilevaSondaggi(s, forza=false) {
    const sg=s.sondaggi||(s.sondaggi={governo:54,partiti:{},ultimaRilevazione:0,storico:[]});
    if(!forza && s.turno-(sg.ultimaRilevazione||0)<4)return;
    const ids=s.parlamento.partiti.map(p=>p.id);
    const pesi={verdi:0.34,blu:0.33,rossi:0.19,gialli:0.09,ind:0.05};
    const base=ids.map(id=>{
      const p=s.parlamento.partiti.find(x=>x.id===id);
      const quota=100*p.seggi/s.parlamento.totale;
      const fid=Number(s.politica?.fiducia?.[id]??60);
      const leader=Number(s.leadership?.[id]?.fiducia??60);
      const bonus=Number(s.campagna?.bonus?.[id]??0);
      const governo=p.governo? (s.consenso-50)*0.16+(s.stabilita-60)*0.05 : (50-s.consenso)*0.04;
      return {id,val:Math.max(1,quota+(fid-60)*0.07+(leader-60)*0.035+bonus+governo)};
    });
    const somma=base.reduce((a,x)=>a+x.val,0);
    const valori={};base.forEach(x=>valori[x.id]=Math.round(x.val/somma*1000)/10);
    // Corregge l'arrotondamento per ottenere esattamente il 100%.
    const diff=Math.round((100-Object.values(valori).reduce((a,x)=>a+x,0))*10)/10;
    valori[base.slice().sort((a,b)=>b.val-a.val)[0].id]+=diff;
    const gov=clamp(s.consenso+(s.stabilita-60)*0.12+(govSeggi(s)-101)*0.035,5,95);
    sg.governo=Math.round(gov*10)/10;sg.partiti=valori;sg.ultimaRilevazione=s.turno;
    sg.storico.unshift({turno:s.turno,governo:sg.governo,partiti:Object.assign({},valori)});
    sg.storico=sg.storico.slice(0,12);
    Object.keys(s.leadership||{}).forEach(id=>{
      const l=s.leadership[id], fid=Number(s.politica?.fiducia?.[id]??60);
      l.tensione=clamp(l.tensione+(fid<45?3:fid>70?-2:0)+(valori[id]<20?2:0),0,100);
      if(l.tensione>65)l.fiducia=clamp(l.fiducia-2,0,100);
      else if(l.tensione<30)l.fiducia=clamp(l.fiducia+1,0,100);
    });
    s.campagna.bonus=Object.fromEntries(ids.map(id=>[id,Math.max(0,Number(s.campagna.bonus?.[id]||0)*0.72)]));
  }

  function campagnaElettorale(partito, strategia) {
    const s=State, prossima=ELEZIONI.find(t=>t>s.turno);
    if(!prossima || prossima-s.turno>12)return err('La campagna elettorale si apre negli ultimi 12 turni prima del voto.');
    if(s.turno-(s.campagna?.ultima||0)<3)return err('Puoi lanciare una nuova iniziativa ogni 3 turni.');
    const p=s.parlamento.partiti.find(x=>x.id===partito);
    if(!p)return err('Partito non riconosciuto.');
    const opzioni={
      territorio:{nome:'Incontri sul territorio',costo:0.45,bonus:1.4,cons:0.4,fid:1},
      media:{nome:'Campagna sui media',costo:0.75,bonus:2.0,cons:0.7,fid:0},
      programma:{nome:'Presentazione del programma',costo:0.6,bonus:1.7,cons:0.3,fid:2}
    };
    const x=opzioni[strategia];if(!x)return err('Strategia elettorale non riconosciuta.');
    if(s.tesoro<x.costo)return err('Risorse insufficienti per la campagna.');
    muovi(s,-x.costo);
    s.campagna.bonus[partito]=clamp(Number(s.campagna.bonus[partito]||0)+x.bonus,0,6);
    s.consenso=clamp(s.consenso+x.cons,0,100);
    if(s.politica){s.politica.fiducia=s.politica.fiducia||{};if(s.politica.fiducia[partito]!=null)s.politica.fiducia[partito]=clamp(s.politica.fiducia[partito]+x.fid,0,100);}
    s.campagna.ultima=s.turno;
    s.campagna.storico.unshift({turno:s.turno,partito:p.nome,nome:x.nome,costo:x.costo});
    s.campagna.storico=s.campagna.storico.slice(0,8);
    log(s,x.nome+' · '+p.nome,'pos','festa');
    rilevaSondaggi(s,true);
    return ok(x.nome+' avviata per '+p.nome+'.');
  }

  function gestisciLeadership(partito, azione) {
    const s=State, l=s.leadership?.[partito], p=s.parlamento.partiti.find(x=>x.id===partito);
    if(!l||!p||!p.governo)return err('Puoi intervenire solo sulla leadership di un partito della coalizione.');
    if(azione==='sostieni'){
      if(s.tesoro<0.25)return err('Risorse insufficienti per organizzare un congresso di sostegno.');
      muovi(s,-0.25);l.fiducia=clamp(l.fiducia+8,0,100);l.tensione=clamp(l.tensione-12,0,100);
      s.politica.fiducia[partito]=clamp((s.politica.fiducia[partito]??60)+2,0,100);
      log(s,'Il Governo sostiene la leadership di '+p.nome,'pos','festa');
      return ok('La leadership di '+p.nome+' è stata rafforzata.');
    }
    if(azione==='media'){
      l.tensione=clamp(l.tensione-10,0,100);s.politica.fiducia[partito]=clamp((s.politica.fiducia[partito]??60)+4,0,100);
      s.stabilita=clamp(s.stabilita+0.5,0,100);
      log(s,'Mediazione interna nella coalizione con '+p.nome,'neu','legge');
      return ok('La mediazione ha ridotto le tensioni interne.');
    }
    return err('Intervento politico non riconosciuto.');
  }

  // ---- il turno ----
  function turno() {
    const s = State;
    if (s.fine || s.politica?.crisiGoverno) return null;
    const prev = { pil: s.pil, lav: s.lavoro, cons: s.consenso, stab: s.stabilita, tes: s.tesoro, deb: s.debito, infl: s.inflazione };
    const rep = { turno: s.turno + 1, voti: [], eventi: [], scaduti: [], elezioni: null, avvisi: [], delta: {} };

    // 1. avanzamento autonomo dell'istruttoria legislativa.
    s.leggi.inDiscussione.forEach(d => {
      if(d.fase==='commissione'){
        d.avanzamento=Number(d.avanzamento||0)+1;
        if(d.avanzamento===1&&!d.emendamento){
          const L=D.legge(d.id), themes={
            energia:'Destinare una quota degli investimenti alla riduzione delle bollette per le famiglie vulnerabili.',
            lavoro:'Introdurre una verifica semestrale sulla qualità dei contratti e sui posti di lavoro creati.',
            ambiente:'Prevedere controlli indipendenti e una relazione annuale sugli effetti ambientali.',
            sanita:'Vincolare una parte delle risorse alla riduzione delle liste d’attesa.',
            istruzione:'Prevedere indicatori pubblici su dispersione scolastica e accesso ai servizi.',
            default:'Inserire una clausola di trasparenza, monitoraggio e relazione annuale al Parlamento.'
          };
          d.emendamento={proponente:'Rossi',testo:themes[L.cat?.toLowerCase()]||themes[L.id]||themes.default,stato:'Proposto'};
          rep.avvisi.push('L’opposizione presenta un emendamento a '+L.nome+'.');
          log(s,'L’opposizione deposita un emendamento a '+L.nome,'neu','legge');
        }
        if(d.avanzamento>=2&&!d.emendamento?.stato?.startsWith('Proposto')){d.fase='camera';rep.avvisi.push(D.legge(d.id).nome+' è pronto per il voto della Camera.');}
        if(d.avanzamento>=3&&d.emendamento?.stato==='Proposto'){d.fase='camera';rep.avvisi.push(D.legge(d.id).nome+' è pronto per il voto della Camera, con emendamento ancora da valutare.');}
      }
    });
    s.leggi.inDiscussione=s.leggi.inDiscussione.filter(d=>d.fase!=='respinta');
    s.leggi.storicoVoti=s.leggi.storicoVoti.slice(0,10);

    // 2. eventi scaduti: scelta predefinita (la peggiore)
    s.eventi.slice().forEach(ev => {
      if (s.turno + 1 >= ev.scade) {
        const def = D.evento(ev.id);
        risolvi(s, ev, def, Object.assign({}, def.scelte[def.def], { costo: 0 }));
        rep.scaduti.push(def.titolo);
      }
    });

    // 3. simulazione
    const m = modsTotali(s), b = s.budget, dt = b.tasse - 33;
    const fl = flussoPrevisto(s, m);
    const neg = Math.max(0, -s.tesoro);
    const usura = 0.035 * (s.turno - 52);
    const gov = govSeggi(s);
    const ciclo = Math.sin(s.turno / 24) * 0.2;

    const pilT = 0.4 + m.pil - 0.045 * dt + 0.012 * (b.infra - 50) + ciclo - 0.12 * Math.max(0, s.inflazione - 3.2) - 0.02 * Math.max(0, s.debito - 90) - 0.016 * neg;
    const lavT = 92.6 + m.lav + 1.5 * (s.pil - 0.4) - 0.08 * dt;
    const inflT = 2.1 + m.infl + 0.8 * (s.pil - 0.4) + clamp(-fl.saldo * 1.5, -0.2, 0.6) + Math.min(1, 0.05 * neg);
    const idxT = {
      sanita: 62 + 0.5 * (b.sociale - 50) + m.san,
      istruzione: 58 + 0.3 * (b.sociale - 50) + m.ist,
      ambiente: 55 + m.amb,
      sicurezza: 60 + 0.5 * (b.sicurezza - 50) + m.sic
    };
    const gT = {
      lav: 55 + m.gr.lav + 3 * (s.lavoro - 92.6) - 4 * (s.inflazione - 2.1) + 0.15 * (b.sociale - 50) - 0.4 * dt - usura,
      imp: 52 + m.gr.imp + 6 * (s.pil - 0.4) - 0.8 * dt - 1.5 * (s.inflazione - 2.1) + 0.1 * (b.infra - 50) - usura,
      gio: 50 + m.gr.gio + 0.25 * (s.indici.istruzione - 58) + 0.15 * (s.indici.ambiente - 55) + 2 * (s.lavoro - 92.6) - 0.2 * dt - usura,
      anz: 57 + m.gr.anz + 0.3 * (s.indici.sanita - 62) + 0.15 * (s.indici.sicurezza - 60) - 3 * (s.inflazione - 2.1) - 0.3 * dt - usura
    };
    const stabT = 68 + m.stab + 0.25 * (s.consenso - 54) + (gov - 122) * 0.12 - (gov < 101 ? 8 : 0) + 0.15 * (s.indici.sicurezza - 60) - Math.min(neg, 10);

    s.pil += (pilT - s.pil) * 0.25 + (rnd(s) - 0.5) * 0.08;
    s.lavoro = clamp(s.lavoro + (lavT - s.lavoro) * 0.15, 70, 99);
    s.inflazione = clamp(s.inflazione + (inflT - s.inflazione) * 0.2, -2, 25);
    for (const k in idxT) s.indici[k] = clamp(s.indici[k] + (idxT[k] - s.indici[k]) * 0.08, 0, 100);
    for (const g in gT) s.gruppi[g] = clamp(s.gruppi[g] + (gT[g] - s.gruppi[g]) * 0.12, 0, 100);
    const cT = 0.3 * s.gruppi.lav + 0.2 * s.gruppi.imp + 0.25 * s.gruppi.gio + 0.25 * s.gruppi.anz;
    s.consenso = clamp(s.consenso + (cT - s.consenso) * 0.3, 0, 100);
    s.stabilita = clamp(s.stabilita + (stabT - s.stabilita) * 0.1, 0, 100);

    muovi(s, fl.saldo);
    s.debito = Math.max(0, s.debito - 0.04 * Math.max(0, s.pil));
    s.negStreak = s.tesoro < -15 ? s.negStreak + 1 : 0;

    // 4. calendario
    s.turno += 1;
    s.settimana += 1;
    if (s.settimana > 4) { s.settimana = 1; s.mese += 1; }
    if (s.mese > 11) { s.mese = 0; s.anno += 1; }
    if (s.diplomazia) Object.keys(s.diplomazia).forEach(id => {
      const n = s.diplomazia[id], base = D.NAZIONI.find(x => x.id === id).rel + (n.accordo ? 8 : 0);
      n.rel += (base - n.rel) * 0.015;
    });

    // 4-bis. dinamiche politiche autonome, una volta al mese di gioco
    politicaAutonoma(s, rep);
    rilevaSondaggi(s);
    // Scandali e tensioni personali nel Consiglio: episodi rari, ma con conseguenze.
    const ms=s.ministri||(s.ministri={fiducia:{},scandalo:null,dimissioni:[]});
    const inCarica=Object.values(s.incarichi||{}).filter(Boolean);
    if(!ms.scandalo && s.turno%8===0 && rnd(s)<0.22 && inCarica.length){
      const id=inCarica[Math.floor(rnd(s)*inCarica.length)];
      const nomi={venturi:'R. Venturi',moretti:'E. Moretti',rinaldi:'G. Rinaldi',ferri:'G. Ferri',bianchi:'L. Bianchi',vitale:'S. Vitale'};
      ms.scandalo={ministro:id,nome:nomi[id]||id,turno:s.turno,stato:'Da gestire',accusa:'irregolarità nella gestione di un appalto e rapporti opachi con un gruppo di interesse'};
      rep.avvisi.push('Scandalo al Governo: accuse contro '+ms.scandalo.nome+'.');
      log(s,'Scoppia uno scandalo che coinvolge '+ms.scandalo.nome,'neg','scandalo');
    }
    inCarica.forEach(id=>{
      ms.fiducia[id]=Number(ms.fiducia[id]??68);
      if(ms.fiducia[id]<18 && !ms.dimissioni.some(x=>x.ministro===id&&x.turno===s.turno)){
        const incarico=Object.keys(s.incarichi).find(k=>s.incarichi[k]===id);
        if(incarico)s.incarichi[incarico]=null;
        ms.dimissioni.unshift({turno:s.turno,ministro:id,nome:id,causa:'Perdita di fiducia'});
        s.stabilita=clamp(s.stabilita-1,0,100);
        rep.avvisi.push('Dimissioni: '+id+' lascia il Governo.');
        log(s,id+' si dimette dal Governo','neg','proteste');
      }
    });

    // 5. elezioni
    if (ELEZIONI.includes(s.turno)) {
      rep.elezioni = elezioni(s);
      rep.elezioni.gov=govSeggi(s);
      rep.elezioni.verdi=s.parlamento.partiti.find(p=>p.id==='verdi').seggi;
      rep.elezioni.blu=s.parlamento.partiti.find(p=>p.id==='blu').seggi;
      log(s, 'Elezioni politiche: nuova maggioranza di '+rep.elezioni.gov+' seggi', 'neu', 'festa');
    }

    // 6. nuovo evento
    const nuovo = pescaEvento(s);
    if (nuovo) {
      const uid = s.uidNext++;
      s.eventi.push({ uid, id: nuovo.id, nato: s.turno, scade: s.turno + 5 });
      s.ultimoEvento[nuovo.id] = s.turno;
      log(s, nuovo.titolo, nuovo.tipo, nuovo.thumb, { uid });
      rep.eventi.push(nuovo.titolo);
    }

    // 7. archivio, deltas, avvisi
    s.storia.push({ t: s.turno, pil: s.pil, infl: s.inflazione, lav: s.lavoro, tes: s.tesoro, deb: s.debito, cons: s.consenso });
    if (s.storia.length > 80) s.storia.shift();
    s.ultimo = { dPil: s.pil, dDis: -(s.lavoro - prev.lav), dCons: s.consenso - prev.cons };
    rep.delta = { pil: s.pil, lav: s.lavoro - prev.lav, cons: s.consenso - prev.cons, stab: s.stabilita - prev.stab, tes: s.tesoro - prev.tes, deb: s.debito - prev.deb, infl: s.inflazione - prev.infl };

    if (s.tesoro < 0) rep.avvisi.push('Il tesoro è in rosso.');
    if (s.consenso < 30) rep.avvisi.push('Il consenso è pericolosamente basso.');
    if (s.stabilita < 30) rep.avvisi.push('Le istituzioni sono instabili.');
    if (s.debito > 110) rep.avvisi.push('Il debito supera il 110% del PIL.');
    if (govSeggi(s) < 101) rep.avvisi.push('La coalizione non ha la maggioranza in parlamento.');

    aggiornaPriorita(s);
    s.fine = s.fine || controllaFine(s);
    rep.fine = s.fine;
    s.salva();
    return rep;
  }

  window.Motore = {
    proponi, ritira, negozia, abroga, scegli, setBudget, rimborsa, direttiva, diplo, turno, decisionePolitica, votaSfiducia, formaGoverno, rimpasto, negoziaProgramma, gestisciScandalo, nominaMinistro, decidiEmendamento, votaCamera, votaSenato, promulga, campagnaElettorale, gestisciLeadership, rilevaSondaggi,
    modsTotali, govSeggi, voto, flussoPrevisto, tags, prioritaView, aggiornaPriorita, punteggio, giudizio,
    proiezione: (id, neg) => voto(State, D.legge(id), !!neg),
    it, sg, clamp, ELEZIONI
  };
})();
