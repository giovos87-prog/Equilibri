// Rendering di barra superiore e menu laterale
const fmt = (n, d = 1) => n.toFixed(d).replace('.', ',');

const NAV = [
  { id: 'panoramica', label: 'Panoramica', icon: 'home' },
  { id: 'governo', label: 'Governo', icon: 'crown' },
  { id: 'parlamento', label: 'Parlamento', icon: 'parliament' },
  { id: 'leggi', label: 'Leggi', icon: 'laws' },
  { id: 'economia', label: 'Economia', icon: 'economy' },
  { id: 'societa', label: 'Società', icon: 'society' },
  { id: 'diplomazia', label: 'Diplomazia', icon: 'diplomacy' },
  { id: 'eventi', label: 'Eventi', icon: 'alert' }
];

function renderTopbar(s) {
  const pilSign = s.pil >= 0 ? '+' : '';
  document.getElementById('topbar').innerHTML = `
    <div class="brand">
      ${Icons.crest}
      <div>
        <div class="brand-title">EQUILIBRI 3.3</div>
        <div class="brand-sub">Il Potere delle Leggi</div>
      </div>
    </div>
    <div class="top-cell kingdom">${Icons.flag}<span class="label">${s.regno}</span></div>
    <div class="top-cell date">${Icons.calendar}
      <div class="stack"><span class="label">Anno ${s.anno}</span><span class="small">Turno ${s.turno} / ${s.turniTotali}</span></div>
    </div>
    <div class="top-cell">${Icons.chartUp}
      <div class="stack"><span class="label">PIL</span><span class="value pos">${pilSign}${fmt(s.pil)}%</span></div>
    </div>
    <div class="top-cell">${Icons.coins}
      <div class="stack"><span class="label">Tesoro</span><span class="value">${fmt(s.tesoro)} mld €</span></div>
    </div>
    <div class="top-cell">${Icons.people}
      <div class="stack"><span class="label">Consenso</span><span class="value">${Math.round(s.consenso)}%</span></div>
    </div>
    <div class="top-cell">${Icons.scales}
      <div class="stack"><span class="label">Stabilità</span><span class="value">${Math.round(s.stabilita)}%</span></div>
    </div>
    <div class="top-spacer"></div>
    <div class="top-actions">
      <button class="round-btn" title="Aiuto" data-act="aiuto">${Icons.question}</button>
      <button class="round-btn" title="Impostazioni" data-act="impost">${Icons.gear}</button>
    </div>`;
}

const SCENE = `
<svg viewBox="0 0 240 300" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="sk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fb3d9"/><stop offset=".6" stop-color="#cfe3ea"/><stop offset="1" stop-color="#f4e6c0"/></linearGradient>
    <linearGradient id="wt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4f8aa8"/><stop offset="1" stop-color="#2a5a73"/></linearGradient>
  </defs>
  <rect width="240" height="300" fill="url(#sk)"/>
  <path d="M0 110 L40 70 L70 95 L110 55 L150 90 L190 65 L240 100 V180 H0 Z" fill="#7a95a8"/>
  <path d="M0 125 L50 95 L90 120 L140 85 L200 115 L240 105 V190 H0 Z" fill="#5f8a6a"/>
  <path d="M0 150 Q60 130 120 150 T240 145 V220 H0 Z" fill="#3f7a45"/>
  <!-- castello sul colle -->
  <path d="M10 170 Q40 140 80 150 L110 170 Z" fill="#4a7a3a"/>
  <rect x="38" y="118" width="40" height="34" fill="#e8dcc0" stroke="#7a6a48"/>
  <rect x="34" y="102" width="12" height="50" fill="#efe3c8" stroke="#7a6a48"/>
  <rect x="68" y="108" width="12" height="44" fill="#efe3c8" stroke="#7a6a48"/>
  <path d="M32 102 L40 88 L48 102 Z" fill="#a8452c"/><path d="M66 108 L74 94 L82 108 Z" fill="#a8452c"/>
  <!-- case -->
  ${[0,1,2,3,4,5].map(i=>`
    <rect x="${20+i*34}" y="${190+(i%2)*6}" width="28" height="26" fill="#f1dfae" stroke="#8a6a3a"/>
    <path d="M${17+i*34} ${190+(i%2)*6} L${34+i*34} ${176+(i%2)*6} L${51+i*34} ${190+(i%2)*6} Z" fill="${i%2?'#b3492d':'#c8683a'}" stroke="#7a3a20"/>
    <rect x="${28+i*34}" y="${198+(i%2)*6}" width="6" height="8" fill="#5a3a1a"/>`).join('')}
  <!-- fiume e ponte -->
  <rect y="232" width="240" height="68" fill="url(#wt)"/>
  <path d="M0 236 H240" stroke="#9fd0e6" stroke-width="1" opacity=".6"/>
  <path d="M-10 244 Q30 225 70 244 T150 244 T250 244 V256 H-10 Z" fill="#c9bfa0" stroke="#6a5a3a" stroke-width="1.5"/>
  <path d="M10 256 Q30 240 50 256 M70 256 Q90 240 110 256 M130 256 Q150 240 170 256 M190 256 Q210 240 230 256" fill="none" stroke="#6a5a3a" stroke-width="2"/>
  <!-- alberi -->
  ${[8,226,214].map((x,i)=>`<circle cx="${x}" cy="${268+i*4}" r="14" fill="#2f6b35"/><circle cx="${x+6}" cy="${262+i*4}" r="10" fill="#3f8a45"/>`).join('')}
</svg>`;

function renderSidebar(s) {
  const items = NAV.map(n => `
    <button class="nav-item ${s.sezione === n.id ? 'active' : ''}" data-nav="${n.id}">
      ${Icons[n.icon]}<span>${n.label}</span>
      ${n.id === 'eventi' && s.eventi.length > 0 ? `<span class="badge">${s.eventi.length}</span>` : ''}
    </button>`).join('');
  document.getElementById('sidebar').innerHTML = `<nav class="nav">${items}</nav><div class="sidebar-scene">${SCENE}</div>`;
  document.querySelectorAll('[data-nav]').forEach(b =>
    b.addEventListener('click', () => State.set({ sezione: b.dataset.nav })));
}

const SEZ = { governo: 'governo', parlamento: 'parlamento', leggi: 'leggi', economia: 'economia', societa: 'societa', diplomazia: 'diplomazia', eventi: 'eventi' };

function turnBar(s) {
  return `<div class="turn-bar"><button class="turn-btn" data-act="turno" ${s.fine ? 'disabled' : ''}>${Icons.crown}<span>Entra nel nuovo turno</span><span class="arr">›</span></button></div>`;
}

let ultimaSezione = null;
function renderMain(s) {
  const main = document.getElementById('main');
  const right = document.getElementById('right');
  const stessa = ultimaSezione === s.sezione;
  const top = main.scrollTop, topR = right.scrollTop;
  if (s.sezione === 'panoramica') {
    main.className = 'pan';
    main.innerHTML = renderPanoramica(s) + turnBar(s);
  } else {
    main.className = 'sec';
    main.innerHTML = Sezioni[SEZ[s.sezione]](s) + turnBar(s);
  }
  right.className = 'dx';
  right.innerHTML = renderDestra(s);
  if (stessa) { main.scrollTop = top; right.scrollTop = topR; }
  ultimaSezione = s.sezione;
}

// ---------- finestre modali e avvisi ----------
function renderModal(s) {
  const el = document.getElementById('modal');
  const m = s.ui.modal;
  if (!m) { el.className = ''; el.innerHTML = ''; return; }
  const sg = Motore.sg, it = Motore.it;
  let html = '';
  if (m.tipo === 'report') {
    const r = m.rep, d = r.delta;
    const cella = (n, v, bene) => `<div><span>${n}</span><b class="${bene ? 'pos' : 'neg'}">${v}</b></div>`;
    html = `<div class="modal-box"><header>Turno ${r.turno}</header><div class="mb">
      <div class="rep-grid">
        ${cella('PIL', sg(s.pil) + '%', s.pil >= 0)}${cella('Occupazione', sg(d.lav, 2) + ' p.p.', d.lav >= 0)}${cella('Consenso', sg(d.cons) + ' p.p.', d.cons >= 0)}
        ${cella('Stabilità', sg(d.stab) + ' p.p.', d.stab >= 0)}${cella('Tesoro', sg(d.tes, 2) + ' mld', d.tes >= 0)}${cella('Debito', sg(d.deb, 2) + ' p.p.', d.deb <= 0)}
      </div>
      ${r.voti.length ? '<h4>Votazioni in parlamento</h4><ul>' + r.voti.map(v => `<li><b>${v.nome}</b>: ${v.ok ? 'approvata' : 'respinta'} (${v.si}–${v.no})</li>`).join('') + '</ul>' : ''}
      ${r.elezioni ? `<h4>Elezioni politiche</h4><div>La coalizione di governo ottiene <b>${r.elezioni.gov}</b> seggi su 200 (Verdi ${r.elezioni.verdi}, Blu ${r.elezioni.blu}).</div>` : ''}
      ${r.eventi.length ? '<h4>Nuovo evento</h4><ul>' + r.eventi.map(t => `<li>${t}</li>`).join('') + '</ul>' : ''}
      ${r.scaduti.length ? '<h4>Eventi non gestiti</h4><ul>' + r.scaduti.map(t => `<li>${t}: è stata applicata la scelta predefinita.</li>`).join('') + '</ul>' : ''}
      ${r.avvisi.length ? '<h4>Attenzione</h4><ul>' + r.avvisi.map(t => `<li>${t}</li>`).join('') + '</ul>' : ''}
      </div><div class="foot"><button class="btn" data-act="chiudi">Continua</button></div></div>`;
  } else if (m.tipo === 'fine') {
    const f = m.rep.fine, vit = f.esito === 'vittoria';
    html = `<div class="modal-box ${vit ? 'win' : ''}"><header>${vit ? 'Vittoria' : 'Sconfitta'}: ${f.titolo}</header><div class="mb">
      ${vit ? `<div class="big-score">${f.punteggio}</div><div style="text-align:center">punti di equilibrio su 100</div>` : ''}
      <p style="margin-top:10px">${f.testo}</p>
      <p style="margin-top:8px">Turno ${s.turno} · Consenso ${Math.round(s.consenso)}% · Stabilità ${Math.round(s.stabilita)}% · Debito ${it(s.debito)}%</p></div>
      <div class="foot"><button class="btn" data-act="nuova">Nuova partita</button><button class="btn ghost" data-act="chiudi">Chiudi</button></div></div>`;
  } else if (m.tipo === 'aiuto') {
    html = `<div class="modal-box"><header>Come si gioca</header><div class="mb">
      <p>Governi il Regno di Valdoria fino al turno ${s.turniTotali}. Ogni turno è una settimana: premi <b>«Entra nel nuovo turno»</b> per farla scorrere.</p>
      <h4>Cosa puoi fare</h4><ul>
      <li><b>Leggi</b>: proponi una legge; passa in commissione, poi alla Camera (101 voti su 200), al Senato (51 su 100) e infine al Re per la promulgazione. Gli effetti partono dopo la promulgazione.</li>
      <li><b>Economia</b>: regola tasse e spese. Tieni il saldo in positivo.</li>
      <li><b>Eventi</b>: decidi prima che scadano, o sarà scelta la soluzione peggiore.</li>
      <li><b>Governo</b>: assegna gli incarichi, effettua rimpasti e usa le direttive dei ministri. Scandali e dimissioni possono lasciare ministeri vacanti.</li>
      <li><b>Diplomazia</b>: accordi e patti con le nazioni vicine.</li><li><b>Parlamento</b>: i partner possono avanzare richieste; accoglierle, negoziarle o respingerle cambia la fiducia nella coalizione. L’opposizione aumenta la pressione quando gli indicatori peggiorano.</li><li><b>Crisi di governo</b>: una sfiducia approvata apre consultazioni. Scegli un Governo di compromesso, di unità nazionale o nuove elezioni; durante le consultazioni il tempo è sospeso.</li><li><b>Patti di maggioranza</b>: gli accordi programmatici costano risorse e rafforzano la fiducia dei partner.</li></ul>
      <h4>Come si perde</h4><div>Consenso o stabilità sotto il 10%, debito oltre il 150% del PIL, o tesoro sotto −15 mld per 12 turni di fila.</div>
      </div><div class="foot"><button class="btn" data-act="chiudi">Ho capito</button></div></div>`;
  } else if (m.tipo === 'impost') {
    html = `<div class="modal-box"><header>Impostazioni</header><div class="mb">
      <p>La partita si salva da sola alla fine di ogni turno, in questo browser.</p></div>
      <div class="foot"><button class="btn sec" data-act="nuova">Nuova partita</button><button class="btn" data-act="chiudi">Chiudi</button></div></div>`;
  }
  el.className = 'on';
  el.innerHTML = html;
}

let toastT = null;
function toast(msg, ok) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'on' + (ok ? '' : ' err');
  clearTimeout(toastT);
  toastT = setTimeout(() => { t.className = ''; }, 2300);
}

function renderAll(s) { renderTopbar(s); renderSidebar(s); renderMain(s); renderModal(s); }

// ---------- azioni ----------
function eseguiTurno() {
  if (State.politica?.crisiGoverno) { toast('Consultazioni in corso: forma prima il nuovo Governo o convoca elezioni.', false); return null; }
  const rep = Motore.turno();
  if (!rep) { toast('Il turno non può avanzare in questo momento.', false); return null; }
  State.ui.modal = rep.fine ? { tipo: 'fine', rep } : { tipo: 'report', rep };
  return null;
}
const AZ = {
  turno: eseguiTurno,
  politica: d => Motore.decisionePolitica(d.id, d.scelta),
  sfiducia: () => Motore.votaSfiducia(),
  governo: d => Motore.formaGoverno(d.scelta),
  programma: d => Motore.negoziaProgramma(d.partito,d.tema),
  campagna: d => Motore.campagnaElettorale(d.partito,d.strategia),
  leadership: d => Motore.gestisciLeadership(d.partito,d.scelta),
  scandalo: d => Motore.gestisciScandalo(d.scelta),
  emendamento: d => Motore.decidiEmendamento(d.id,d.scelta),
  camera: d => Motore.votaCamera(d.id), senato: d => Motore.votaSenato(d.id), promulga: d => Motore.promulga(d.id),
  proponi: d => Motore.proponi(d.id), ritira: d => Motore.ritira(d.id), negozia: d => Motore.negozia(d.id), abroga: d => Motore.abroga(d.id),
  scegli: d => Motore.scegli(+d.uid, +d.idx), rimborsa: () => Motore.rimborsa(), direttiva: d => Motore.direttiva(d.id), diplo: d => Motore.diplo(d.id, d.az),
  tab: d => { State.ui.leggiTab = d.id; return null; },
  cat: d => { State.ui.leggiCat = d.id; return null; },
  chiudi: () => { State.ui.modal = null; return null; },
  nuova: () => { State.cancellaSalvataggio(); State.nuova(true); return null; },
  aiuto: () => { State.ui.modal = { tipo: 'aiuto' }; return null; },
  impost: () => { State.ui.modal = { tipo: 'impost' }; return null; }
};

document.addEventListener('click', ev => {
  const a = ev.target.closest('[data-act]');
  if (a && !a.disabled) {
    const res = AZ[a.dataset.act] ? AZ[a.dataset.act](a.dataset) : null;
    if (res && res.msg) toast(res.msg, res.ok);
    if (!State.fine || a.dataset.act === 'nuova') State.salva();
    State.emit();
    return;
  }
  const g = ev.target.closest('[data-go]');
  if (g) {
    if (g.dataset.min) State.ui.ministro = g.dataset.min;
    State.set({ sezione: g.dataset.go });
  }
});
document.addEventListener('input', ev => {
  const r = ev.target.closest('[data-budget]');
  if (r) { const o = document.getElementById('o-' + r.dataset.budget); if (o) o.textContent = r.value + (r.dataset.unita || ''); }
});
document.addEventListener('change', ev => {
  const rimp = ev.target.closest('[data-rimpasto]');
  if (rimp) {
    const res = Motore.rimpasto(rimp.dataset.rimpasto, rimp.value);
    if (res && res.msg) toast(res.msg, res.ok);
    State.salva(); State.emit(); return;
  }
  const r = ev.target.closest('[data-budget]');
  if (r) { Motore.setBudget(r.dataset.budget, +r.value); State.salva(); State.emit(); }
});

// ---------- adattamento alla finestra ----------
function adatta() {
  const sc = Math.min(window.innerWidth / 1672, window.innerHeight / 941);
  const x = (window.innerWidth - 1672 * sc) / 2, y = (window.innerHeight - 941 * sc) / 2;
  document.getElementById('game').style.transform = `translate(${x}px,${y}px) scale(${sc})`;
}
window.addEventListener('resize', adatta);
adatta();

// ---------- avvio ----------
State.nuova(true);
State.carica();
State.subscribe(renderAll);
renderAll(State);
