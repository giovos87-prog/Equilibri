// Sezioni del menu: Governo, Parlamento, Leggi, Economia, Società, Diplomazia, Eventi
(function () {
  const D = DATA, M = Motore, it = M.it, sg = M.sg, clamp = M.clamp;
  const I = () => window.Icone;

  const head = (titolo, sub) => `<div class="sec-head"><div class="plate"><h1>${titolo}</h1>${sub ? `<div class="sub">${sub}</div>` : ''}</div></div>`;
  const tagHtml = tags => tags.map(t => `<span class="tag ${t.good ? 'good' : 'bad'}">${t.t}</span>`).join('');
  const barra = (v, max, cls, soglia) => `<div class="bar ${cls || 'g'}"><i style="width:${clamp(v / max * 100, 0, 100)}%"></i>${soglia != null ? `<u style="left:${soglia / max * 100}%"></u>` : ''}</div>`;
  const colore = v => (v >= 60 ? 'g' : v >= 40 ? 'y' : 'r');
  const btn = (txt, attrs, opz) => {
    opz = opz || {};
    return `<button class="btn ${opz.cls || ''}" ${attrs} ${opz.dis ? `disabled title="${opz.dis}"` : ''}>${txt}</button>`;
  };
  const panel = (titolo, icona, corpo, cls) => `<section class="panel ${cls || ''}"><header>${icona || ''}${titolo}</header><div class="body">${corpo}</div></section>`;

  // ---------------- GOVERNO ----------------
  function governo(s) {
    const gov = M.govSeggi(s);
    const stato = gov >= 111 ? 'Governo stabile' : gov >= 101 ? 'Maggioranza risicata' : 'Governo in minoranza';
    const partitiGov=s.parlamento.partiti.filter(p=>p.governo);
    const formula=partitiGov.map(p=>`${p.nome} ${p.seggi}`).join(' + ') || 'Nessun partito al Governo';
    const top = panel('Coalizione di governo', I().parl,
      `<div class="coal"><div>${formula} = <b>${gov} / ${s.parlamento.totale}</b> — ${stato}</div>
       <div class="mini-row"><span>Stabilità</span>${barra(s.stabilita, 100, colore(s.stabilita))}<b>${Math.round(s.stabilita)}%</b></div></div>`);
    const card = (m, i) => {
      const idPersona=(s.incarichi||{})[m.id]; const titolare=window.Ministri.find(x=>x.id===idPersona); const mn=titolare||window.Ministri[i], d=m.dir, pronta = (s.dir[m.id] || 0) <= s.turno;
      const k = (window.Ministri.find(x=>x.id===idPersona)||m).comp / 75;
      const eff = {};
      if (d.i) for (const key in d.i) eff[key] = (typeof d.i[key] === 'number') ? d.i[key] * k : d.i[key];
      if (d.i && d.i.gr) { eff.gr = {}; for (const g in d.i.gr) eff.gr[g] = d.i.gr[g] * k; }
      if (d.i && d.i.idx) { eff.idx = {}; for (const x in d.i.idx) eff.idx[x] = d.i.idx[x] * k; }
      let tg = M.tags(eff, { una: true });
      if (d.mod) tg = tg.concat(M.tags(d.mod.eff).map(t => ({ t: t.t + ' (' + d.mod.turni + ' turni)', good: t.good })));
      const dis = !pronta ? 'Pronta tra ' + (s.dir[m.id] - s.turno) + ' turni' : (d.costo && s.tesoro < d.costo ? 'Tesoro insufficiente' : '');
      return `<div class="min-big ${s.ui.ministro === m.id ? 'sel' : ''}">
        <div class="mb-pic">${window.Ritratto(mn.p)}</div>
        <div class="mb-txt">
          <div class="mb-name">${idPersona?mn.nome:'Ministero vacante'}</div><div class="mb-role">${window.Ministri[i].ruolo} · ${idPersona?'incarico assegnato':'nomina necessaria'}</div>
          <div class="mini-row"><span>Competenza</span>${barra((window.Ministri.find(x=>x.id===idPersona)||m).comp, 100, colore((window.Ministri.find(x=>x.id===idPersona)||m).comp))}<b>${(window.Ministri.find(x=>x.id===idPersona)||m).comp}</b></div><div class="mini-row"><span>Fiducia</span>${barra(s.ministri?.fiducia?.[idPersona]??65,100,colore(s.ministri?.fiducia?.[idPersona]??65))}<b>${Math.round(s.ministri?.fiducia?.[idPersona]??65)}%</b></div>
          <div class="mb-dir"><b>${d.nome}</b><span>${d.desc}</span><div class="tags">${tagHtml(tg)}</div></div>
          <div class="mb-act"><label class="mini-label">Assegna incarico</label><select data-rimpasto="${m.id}">${window.Ministri.map(x=>`<option value="${x.id}" ${x.id===idPersona?'selected':''}>${x.nome}</option>`).join('')}</select></div>
          <div class="mb-act">${d.costo ? `<span class="cost">${it(d.costo)} mld</span>` : '<span class="cost">gratis</span>'}${btn(pronta ? 'Esegui' : 'In attesa', `data-act="direttiva" data-id="${m.id}"`, { dis: !idPersona?'Ministero vacante: nomina un titolare.':dis })}</div>
        </div></div>`;
    };
    const sc=s.ministri?.scandalo;
    const scandalo=sc?panel('Scandalo al Governo',I().alert,`<div class="law-card"><h3>${sc.nome}</h3><p>Accuse: ${sc.accusa}. Devi decidere come reagire.</p><div class="acts">${btn('Difendi il ministro',`data-act="scandalo" data-scelta="difendi"`,{cls:'sec'})}${btn('Apri indagine indipendente',`data-act="scandalo" data-scelta="indaga"`,{cls:'ghost'})}${btn('Rimuovi dall’incarico',`data-act="scandalo" data-scelta="rimuovi"`,{cls:'danger'})}</div></div>`):'';
    const dim=s.ministri?.dimissioni||[];
    const dimPanel=dim.length?panel('Dimissioni e vacanze',I().alert,dim.slice(0,4).map(x=>`<div class="vote-row ko"><b>${x.nome}</b><span>${x.causa} · turno ${x.turno}</span></div>`).join('')):'';
    return head('GOVERNO', 'Il Consiglio al lavoro') + top + scandalo + `<div class="grid3">${D.CONSIGLIO.map(card).join('')}</div>` + dimPanel;
  }

  // ---------------- PARLAMENTO ----------------
  function parlamento(s) {
    const gov = M.govSeggi(s);
    const prossima = M.ELEZIONI.find(t => t > s.turno);
    const emi = panel('Emiciclo', I().parl, `<div class="parl big">${window.Emiciclo(s.parlamento.partiti, s.parlamento.totale)}<div class="seats">${gov} / ${s.parlamento.totale}</div>
      <div class="stable ${gov >= 111 ? '' : gov >= 101 ? 'warn' : 'bad'}">${gov >= 111 ? 'Governo stabile' : gov >= 101 ? 'Maggioranza risicata' : 'Governo in minoranza'}</div></div>`);
    const righe = s.parlamento.partiti.map(p => `<div class="party-row"><i style="background:${p.colore}"></i><b>${p.nome}</b><span class="ruolo">${p.governo ? 'Governo' : 'Opposizione'}</span>
      <div class="bar"><i style="background:${p.colore};width:${p.seggi}%"></i></div><em>${p.seggi}</em></div>`).join('');
    const partiti = panel('I partiti', I().flag, righe + `<div class="note">Per approvare una legge servono almeno 101 voti su 200.</div>`);
    const voti = s.leggi.storicoVoti.length
      ? s.leggi.storicoVoti.map(v => `<div class="vote-row ${v.ok ? 'ok' : 'ko'}"><b>${v.nome}</b><span>${v.fase||'Votazione'} · ${v.ok ? 'Approvata' : 'Respinta'} ${v.si}–${v.no}</span><em>turno ${v.turno}</em></div>`).join('')
      : '<div class="note">Nessuna votazione finora. Proponi una legge dalla sezione Leggi.</div>';
    const ult = panel('Ultime votazioni', I().target, voti);
    const el = panel('Elezioni', I().check, prossima
      ? `<div class="big-num">${prossima - s.turno}</div><div class="note">turni alle prossime elezioni politiche (turno ${prossima}). Il consenso e la stabilità decidono i seggi della coalizione.</div>`
      : '<div class="note">Non ci sono altre elezioni in questa partita.</div>');
    const pol=s.politica||{fiducia:{verdi:68,blu:68},richieste:[],opposizione:{pressione:0,iniziative:0}};
    const trust=['verdi','blu'].map(id=>{const p=s.parlamento.partiti.find(x=>x.id===id);return `<div class="mini-row"><span>${p.nome}</span>${barra(pol.fiducia?.[id]??68,100,colore(pol.fiducia?.[id]??68))}<b>${Math.round(pol.fiducia?.[id]??68)}%</b></div>`}).join('');
    const req=(pol.richieste||[]).filter(r=>r.stato==='In attesa').map(r=>`<article class="law-card"><div class="lc-top"><h3>${r.nome} · ${r.tema}</h3><span class="cat">Richiesta politica</span></div><p>Il partner chiede al Governo di ${r.testo}.</p><div class="acts">${btn('Accogli',`data-act="politica" data-id="${r.id}" data-scelta="accogli"`)}${btn('Negozia',`data-act="politica" data-id="${r.id}" data-scelta="negozia"`,{cls:'sec'})}${btn('Respingi',`data-act="politica" data-id="${r.id}" data-scelta="respingi"`,{cls:'ghost'})}</div></article>`).join('')||'<div class="note">Nessuna richiesta pendente dai partner.</div>';
    const iniziativa=pol.opposizione?.ultimaProposta?`<div class="note"><b>Ultima iniziativa dell’opposizione · turno ${pol.opposizione.ultimaProposta.turno}</b><br>${pol.opposizione.ultimaProposta.tema}</div>`:'';
    const mozione=pol.mozione?`<article class="law-card"><div class="lc-top"><h3>MOZIONE DI SFIDUCIA</h3><span class="cat">${pol.mozione.stato}</span></div><p>Presentata da ${pol.mozione.proponente} ${pol.mozione.motivo?`· Motivo: ${pol.mozione.motivo}`:''}</p>${pol.mozione.si!=null?`<div class="note">Esito: ${pol.mozione.si} favorevoli · ${pol.mozione.no} contrari</div>`:''}${pol.mozione.stato==='Da votare'?`<div class="acts">${btn('Metti ai voti la sfiducia',`data-act="sfiducia"`,{cls:'danger'})}</div>`:''}</article>`:'';
    const storicoMozioni=(pol.storicoMozioni||[]).map(m=>`<div class="vote-row ${m.stato==='Respinta'?'ok':'ko'}"><b>Mozione · turno ${m.turno}</b><span>${m.stato} ${m.si!=null?`${m.si}–${m.no}`:''}</span></div>`).join('');
    const crisiG=pol.crisiGoverno?`<article class="law-card"><div class="lc-top"><h3>CONSULTAZIONI PER IL NUOVO GOVERNO</h3><span class="cat">Crisi aperta · turno ${pol.crisiGoverno.turno}</span></div><p>Il Governo è caduto dopo il voto di sfiducia (${pol.crisiGoverno.si}–${pol.crisiGoverno.no}). La legislatura non è finita: scegli come ricostruire una maggioranza.</p><div class="acts">${btn('Governo di compromesso',`data-act="governo" data-scelta="compromesso"`)}${btn('Unità nazionale',`data-act="governo" data-scelta="unita"`,{cls:'sec'})}${btn('Elezioni anticipate',`data-act="governo" data-scelta="elezioni"`,{cls:'ghost'})}</div></article>`:'';
    const accordi=(s.programma?.accordi||[]).map(a=>`<div class="vote-row ok"><b>${a.nome} · ${a.partito}</b><span>Turno ${a.turno}</span></div>`).join('');
    const programma=panel('Patto di maggioranza',I().flag,`<div class="note">Negozia priorità condivise: costano risorse, ma rafforzano la fiducia dei partner.</div>`+['verdi','blu'].filter(id=>s.parlamento.partiti.some(p=>p.id===id&&p.governo)).map(id=>`<div class="law-card"><b>${id==='verdi'?'Verdi':'Blu'}</b><div class="acts">${btn('Patto sociale',`data-act="programma" data-partito="${id}" data-tema="sociale"`,{cls:'sec'})}${btn('Crescita',`data-act="programma" data-partito="${id}" data-tema="crescita"`,{cls:'sec'})}${btn('Patto verde',`data-act="programma" data-partito="${id}" data-tema="ambiente"`,{cls:'sec'})}</div></div>`).join('')+(accordi?`<div class="subhead">Accordi firmati</div>${accordi}`:''));
    const autonomia=panel('Equilibri della coalizione',I().flag,crisiG+trust+`<div class="note">Pressione dell’opposizione: ${pol.opposizione?.pressione??0}/10 · iniziative autonome: ${pol.opposizione?.iniziative??0}</div>`+iniziativa+mozione+(storicoMozioni?`<div class="subhead">Mozioni precedenti</div>${storicoMozioni}`:'')+req);
    const sg=s.sondaggi||{governo:s.consenso,partiti:{},storico:[]};
    const righeSondaggio=s.parlamento.partiti.map(p=>{
      const val=Number(sg.partiti?.[p.id]??(100*p.seggi/200));
      return `<div class="mini-row"><span>${p.nome}</span><div class="bar"><i style="width:${val}%;background:${p.colore}"></i></div><b>${val.toFixed(1).replace('.',',')}%</b></div>`;
    }).join('');
    const storicoSondaggi=(sg.storico||[]).slice(0,5).map(x=>`<div class="vote-row"><b>Turno ${x.turno}</b><span>Governo ${Number(x.governo).toFixed(1).replace('.',',')}%</span></div>`).join('');
    const sondaggi=panel('Sondaggi e consenso',I().chart,`<div class="big-num">${Number(sg.governo??s.consenso).toFixed(1).replace('.',',')}%</div><div class="note">Giudizio positivo sull’operato del Governo · ultima rilevazione: turno ${sg.ultimaRilevazione??s.turno}</div>${righeSondaggio}${storicoSondaggi?`<div class="subhead">Rilevazioni precedenti</div>${storicoSondaggi}`:''}`);
    const prossimaCampagna=M.ELEZIONI.find(t=>t>s.turno),aperta=prossimaCampagna!=null&&prossimaCampagna-s.turno<=12;
    const camp=s.campagna||{ultima:0,bonus:{},storico:[]};
    const scelteCampagna=['verdi','blu'].filter(id=>s.parlamento.partiti.some(p=>p.id===id&&p.governo)).map(id=>`<div class="law-card"><b>${id==='verdi'?'Verdi':'Blu'} · vantaggio campagna ${Number(camp.bonus?.[id]||0).toFixed(1)}</b><div class="acts">${btn('Territorio',`data-act="campagna" data-partito="${id}" data-strategia="territorio"`,{cls:'sec',dis:!aperta?'Disponibile negli ultimi 12 turni prima delle elezioni':''})}${btn('Media',`data-act="campagna" data-partito="${id}" data-strategia="media"`,{cls:'sec',dis:!aperta?'Disponibile negli ultimi 12 turni prima delle elezioni':''})}${btn('Programma',`data-act="campagna" data-partito="${id}" data-strategia="programma"`,{cls:'sec',dis:!aperta?'Disponibile negli ultimi 12 turni prima delle elezioni':''})}</div></div>`).join('');
    const storicoCamp=(camp.storico||[]).slice(0,4).map(x=>`<div class="vote-row"><b>${x.partito}</b><span>${x.nome} · turno ${x.turno}</span></div>`).join('');
    const campagna=panel('Campagna elettorale',I().flag,`<div class="note">${aperta?`Campagna aperta: ${prossimaCampagna-s.turno} turni al voto.`:prossimaCampagna?`Si aprirà negli ultimi 12 turni prima del voto (turno ${prossimaCampagna}).`:'Non sono previste altre elezioni.'} Ogni iniziativa ha un costo per il tesoro.</div>${scelteCampagna}${storicoCamp}`);
    const leadership=panel('Leadership e coesione',I().people,['verdi','blu'].filter(id=>s.parlamento.partiti.some(p=>p.id===id&&p.governo)).map(id=>{
      const l=s.leadership?.[id]||{fiducia:65,tensione:20};
      return `<div class="law-card"><b>${id==='verdi'?'Verdi':'Blu'}</b><div class="mini-row"><span>Fiducia del leader</span>${barra(l.fiducia,100,colore(l.fiducia))}<b>${Math.round(l.fiducia)}%</b></div><div class="mini-row"><span>Tensione interna</span>${barra(l.tensione,100,l.tensione>60?'r':'g')}<b>${Math.round(l.tensione)}%</b></div><div class="acts">${btn('Sostieni il leader',`data-act="leadership" data-partito="${id}" data-scelta="sostieni"`,{cls:'sec'})}${btn('Mediazione interna',`data-act="leadership" data-partito="${id}" data-scelta="media"`,{cls:'ghost'})}</div></div>`;
    }).join('')||'<div class="note">Nessun partito di coalizione al Governo.</div>');
    return head('PARLAMENTO' , 'Duecento seggi, cinque partiti') + `<div class="grid2">${emi}${partiti}</div><div class="grid2">${ult}${el}</div><div class="grid2">${sondaggi}${leadership}</div>${campagna}${programma}${autonomia}`;
  }

  // ---------------- LEGGI ----------------
  function leggeCard(s, L, modo) {
    const d = s.leggi.inDiscussione.find(x => x.id === L.id);
    const v = M.proiezione(L.id, d && d.neg);
    const blocco = (s.leggi.bloccate[L.id] || 0) - s.turno;
    const supporto = `<div class="support"><span>Sostegno previsto</span>${barra(v.si, 200, v.ok ? 'g' : 'r', 101)}<b class="${v.ok ? 'pos' : 'neg'}">${v.si} / 200</b></div>`;
    let azioni = '';
    if (modo === 'catalogo') {
      const dis = s.leggi.inDiscussione.length >= 3 ? 'Al massimo tre leggi in discussione' : blocco > 0 ? 'Respinta da poco: riprova tra ' + blocco + ' turni' : s.tesoro < L.costo ? 'Tesoro insufficiente' : '';
      azioni = btn('Proponi', `data-act="proponi" data-id="${L.id}"`, { dis });
    } else if (modo === 'discussione') {
      const fase=d.fase||'commissione';
      const label={commissione:'In istruttoria · '+(d.avanzamento||0)+'/3',camera:'Pronta per il voto della Camera',senato:'Approvata alla Camera · attende il Senato',promulgazione:'Approvata da entrambe le Camere',respinta:'Respinta'};
      azioni = `<div class="note">${label[fase]||'In iter'}${d.camera?` · Camera ${d.camera.si}–${d.camera.no}`:''}${d.senato?` · Senato ${d.senato.si}–${d.senato.no}`:''}</div>`;
      if(d.emendamento){
        azioni += `<div class="note"><b>Emendamento dell’opposizione:</b> ${d.emendamento.testo}<br>Esito: ${d.emendamento.stato}</div>`;
        if(d.emendamento.stato==='Proposto') azioni += btn('Accogli emendamento',`data-act="emendamento" data-id="${L.id}" data-scelta="accogli"`,{cls:'sec'})+btn('Respingi emendamento',`data-act="emendamento" data-id="${L.id}" data-scelta="respingi"`,{cls:'ghost'});
      }
      if(fase==='camera') azioni+=btn('Vota alla Camera',`data-act="camera" data-id="${L.id}"`);
      if(fase==='senato') azioni+=btn('Vota al Senato',`data-act="senato" data-id="${L.id}"`);
      if(fase==='promulgazione') azioni+=btn('Promulga la legge',`data-act="promulga" data-id="${L.id}"`,{dis:s.tesoro<L.costo?'Tesoro insufficiente':''});
      azioni += btn('Ritira', `data-act="ritira" data-id="${L.id}"`, { cls: 'ghost' });
    } else {
      azioni = btn('Abroga', `data-act="abroga" data-id="${L.id}"`, { cls: 'ghost' });
    }
    return `<article class="law-card"><div class="lc-top"><h3>${L.nome}</h3><span class="cat">${L.cat}</span></div>
      <p>${L.desc}</p><div class="tags">${tagHtml(M.tags(L.eff))}</div>
      ${modo === 'vigore' ? '' : supporto}
      <div class="lc-bot"><span class="cost">${modo === 'vigore' ? 'In vigore' : 'Costo ' + it(L.costo) + ' mld'}</span><div class="acts">${azioni}</div></div></article>`;
  }
  function leggi(s) {
    const tab = s.ui.leggiTab, cat = s.ui.leggiCat;
    const cats = ['Tutte'].concat(Array.from(new Set(D.LEGGI.map(l => l.cat))));
    const tabs = [['catalogo', 'Catalogo'], ['discussione', `In discussione (${s.leggi.inDiscussione.length}/3)`], ['vigore', `In vigore (${s.leggi.inVigore.length})`]]
      .map(([id, t]) => `<button class="tab ${tab === id ? 'on' : ''}" data-act="tab" data-id="${id}">${t}</button>`).join('');
    let corpo = '';
    if (tab === 'catalogo') {
      const lista = D.LEGGI.filter(l => !s.leggi.inVigore.includes(l.id) && !s.leggi.inDiscussione.some(d => d.id === l.id) && (cat === 'Tutte' || l.cat === cat));
      corpo = `<div class="chips">${cats.map(c => `<button class="chip ${cat === c ? 'on' : ''}" data-act="cat" data-id="${c}">${c}</button>`).join('')}</div>
        <div class="grid2">${lista.map(l => leggeCard(s, l, 'catalogo')).join('') || '<div class="note">Nessuna legge in questa categoria.</div>'}</div>`;
    } else if (tab === 'discussione') {
      corpo = s.leggi.inDiscussione.length
        ? `<div class="note top">L’istruttoria avanza con i turni. Poi voti separatamente alla Camera e al Senato; solo dopo puoi promulgare la legge. Negoziare costa 0,3 mld.</div><div class="grid2">${s.leggi.inDiscussione.map(d => leggeCard(s, D.legge(d.id), 'discussione')).join('')}</div>`
        : '<div class="note top">Nessuna legge in discussione. Scegline una dal catalogo.</div>';
    } else {
      corpo = `<div class="grid2">${s.leggi.inVigore.map(id => leggeCard(s, D.legge(id), 'vigore')).join('')}</div>`;
    }
    return head('LEGGI', 'Il potere delle leggi') + `<div class="tabs">${tabs}</div>${corpo}`;
  }

  // ---------------- ECONOMIA ----------------
  function grafico(s, titolo, key, fmt, col) {
    const pts = s.storia.slice(-60).map(p => p[key]);
    const mn = Math.min(...pts), mx = Math.max(...pts), r = (mx - mn) || 1;
    const W = 300, H = 64;
    const xy = pts.map((v, i) => [i / Math.max(1, pts.length - 1) * W, H - 6 - (v - mn) / r * (H - 14)]);
    const path = xy.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
    const prev = pts[Math.max(0, pts.length - 9)], last = pts[pts.length - 1];
    return `<div class="chart"><div class="ch-top"><span>${titolo}</span><b>${fmt(last)}</b></div>
      <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"><path d="${path} L${W} ${H} L0 ${H} Z" fill="${col}" opacity=".16"/><path d="${path}" fill="none" stroke="${col}" stroke-width="2.4" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>
      <div class="ch-foot"><span>min ${fmt(mn)}</span><span>${last >= prev ? '▲' : '▼'} ultimi turni</span><span>max ${fmt(mx)}</span></div></div>`;
  }
  function slider(k, titolo, min, max, val, hint, unita) {
    return `<div class="slider"><div class="sl-top"><b>${titolo}</b><output id="o-${k}">${val}${unita}</output></div>
      <input type="range" min="${min}" max="${max}" value="${val}" data-budget="${k}" data-unita="${unita}"><div class="hint">${hint}</div></div>`;
  }
  function economia(s) {
    const F = M.flussoPrevisto(s), b = s.budget;
    const graf = `<div class="charts">${grafico(s, 'PIL (crescita)', 'pil', v => sg(v) + '%', '#1f8a3c')}${grafico(s, 'Inflazione', 'infl', v => it(v) + '%', '#b3261e')}${grafico(s, 'Occupazione', 'lav', v => it(v) + '%', '#6a3aa8')}
      ${grafico(s, 'Tesoro (mld)', 'tes', v => it(v) + ' mld', '#8a6420')}${grafico(s, 'Debito (% PIL)', 'deb', v => it(v) + '%', '#7a1410')}${grafico(s, 'Consenso', 'cons', v => Math.round(v) + '%', '#1f5fa8')}</div>`;
    const bud = panel('Bilancio dello Stato', I().chart, `
      <div class="bud-grid">
        ${slider('tasse', 'Aliquota media', 20, 48, b.tasse, 'Più entrate, ma meno crescita e consenso.', '%')}
        ${slider('sociale', 'Spesa sociale', 0, 100, b.sociale, 'Sanità e istruzione, gradimento di lavoratori e anziani.', '')}
        ${slider('infra', 'Spesa per le opere', 0, 100, b.infra, 'Sostiene la crescita nel tempo.', '')}
        ${slider('sicurezza', 'Spesa per la sicurezza', 0, 100, b.sicurezza, 'Ordine pubblico e stabilità.', '')}
      </div>`);
    const sal = panel('Cassa per turno', I().chart, `
      <div class="flow"><div><span>Entrate</span><b class="pos">+${it(F.entrate, 2)}</b></div><div><span>Spese</span><b class="neg">−${it(F.spese, 2)}</b></div><div><span>Leggi e accordi</span><b class="${F.extra >= 0 ? 'pos' : 'neg'}">${sg(F.extra, 2)}</b></div></div>
      <div class="saldo ${F.saldo >= 0 ? 'pos' : 'neg'}">Saldo previsto: ${sg(F.saldo, 2)} mld a turno</div>
      <div class="note">Le spese dello Stato crescono col tempo: tieni d'occhio il saldo.</div>
      <div class="acts">${btn('Rimborsa 1 mld di debito', 'data-act="rimborsa"', { dis: s.tesoro < 1 ? 'Servono almeno 1 mld in cassa' : '' })}</div>`);
    return head('ECONOMIA', 'Entrate, spese e indicatori') + graf + `<div class="grid2 wide-left">${bud}${sal}</div>`;
  }

  // ---------------- SOCIETÀ ----------------
  function societa(s) {
    const g = [['lav', 'Lavoratori'], ['imp', 'Imprese'], ['gio', 'Giovani'], ['anz', 'Anziani']];
    const gr = panel('Gradimento per gruppo', '', g.map(([k, n]) => `<div class="mini-row big"><span>${n}</span>${barra(s.gruppi[k], 100, colore(s.gruppi[k]))}<b>${Math.round(s.gruppi[k])}%</b></div>`).join('')
      + `<div class="note">Il consenso generale (${Math.round(s.consenso)}%) è la media pesata dei quattro gruppi.</div>`);
    const x = [['sanita', 'Sanità'], ['istruzione', 'Istruzione'], ['ambiente', 'Ambiente'], ['sicurezza', 'Sicurezza']];
    const idx = panel('Servizi e qualità della vita', '', x.map(([k, n]) => `<div class="mini-row big"><span>${n}</span>${barra(s.indici[k], 100, colore(s.indici[k]))}<b>${Math.round(s.indici[k])}</b></div>`).join('')
      + `<div class="note">Si migliorano con le leggi e con la spesa sociale e per la sicurezza.</div>`);
    const q = [];
    if (s.indici.sanita < 55) q.push('Gli ospedali sono in affanno.');
    if (s.indici.istruzione < 50) q.push('Le scuole perdono qualità: i giovani se ne vanno.');
    if (s.indici.ambiente < 48) q.push('L\'ambiente è in sofferenza: rischio di alluvioni e siccità.');
    if (s.indici.sicurezza < 50) q.push('Cresce la richiesta di sicurezza nelle città.');
    if (s.inflazione > 3) q.push('I prezzi salgono più in fretta degli stipendi.');
    if (s.lavoro < 91) q.push('Troppe persone cercano lavoro.');
    if (s.gruppi.imp < 40) q.push('Le imprese sono scontente e frenano gli investimenti.');
    const umore = s.consenso >= 65 ? 'Il popolo ti ama.' : s.consenso >= 50 ? 'Il regno è sereno.' : s.consenso >= 35 ? 'Il malcontento cresce.' : 'Il popolo è furioso.';
    const qq = panel('Clima del regno', '', `<div class="umore">${umore}</div>` + (q.length ? `<ul class="issues">${q.map(t => `<li>${t}</li>`).join('')}</ul>` : '<div class="note">Nessuna questione urgente.</div>'));
    return head('SOCIETÀ', 'Persone, servizi e umore') + `<div class="grid2">${gr}${idx}</div>${qq}`;
  }

  // ---------------- DIPLOMAZIA ----------------
  const bandiera = c => `<svg viewBox="0 0 60 40"><rect width="60" height="40" fill="${c[0]}"/><path d="M0 40 L60 0 V16 L22 40Z" fill="${c[1]}"/><circle cx="18" cy="14" r="5" fill="${c[1]}" opacity=".9"/><rect width="60" height="40" fill="none" stroke="#5c3f10" stroke-width="2"/></svg>`;
  const livello = r => (r >= 80 ? 'Alleata' : r >= 65 ? 'Cordiale' : r >= 50 ? 'Neutrale' : r >= 35 ? 'Fredda' : 'Ostile');
  function diplomazia(s) {
    const righe = D.NAZIONI.map(N => {
      const n = s.diplomazia[N.id], rel = Math.round(n.rel);
      const d1 = s.turno - n.ultima < 3 ? 'Una missione ogni 3 turni' : s.tesoro < 0.2 ? 'Tesoro insufficiente' : '';
      const d2 = n.accordo ? 'Già firmato' : rel < 55 ? 'Servono relazioni ≥ 55' : s.tesoro < 0.5 ? 'Tesoro insufficiente' : '';
      const d3 = n.patto ? 'Già firmato' : rel < 65 ? 'Servono relazioni ≥ 65' : s.tesoro < 0.8 ? 'Tesoro insufficiente' : '';
      return `<div class="nat-row"><div class="flag">${bandiera(N.col)}</div>
        <div class="nat-info"><h3>${N.nome}</h3><p>${N.desc}</p>
          <div class="mini-row"><span>${livello(rel)}</span>${barra(rel, 100, colore(rel))}<b>${rel}</b></div>
          <div class="tags">${n.accordo ? '<span class="tag good">Accordo commerciale</span>' : ''}${n.patto ? '<span class="tag good">Patto di difesa</span>' : ''}</div></div>
        <div class="nat-act">
          ${btn('Missione <small>0,2 mld</small>', `data-act="diplo" data-id="${N.id}" data-az="missione"`, { dis: d1 })}
          ${btn('Accordo commerciale <small>0,5 mld</small>', `data-act="diplo" data-id="${N.id}" data-az="accordo"`, { cls: 'sec', dis: d2 })}
          ${btn('Patto di difesa <small>0,8 mld</small>', `data-act="diplo" data-id="${N.id}" data-az="patto"`, { cls: 'sec', dis: d3 })}
        </div></div>`;
    }).join('');
    return head('DIPLOMAZIA', 'Alleati, rivali e trattati') + `<div class="nat-list">${righe}</div>
      <div class="note foot">Un accordo commerciale dà PIL ed entrate; un patto di difesa dà stabilità ma può irritare Karvia.</div>`;
  }

  // ---------------- EVENTI ----------------
  function eventi(s) {
    const att = s.eventi.map(ev => {
      const def = D.evento(ev.id), rim = ev.scade - s.turno;
      const sc = def.scelte.map((c, i) => {
        const dis = c.costo && s.tesoro < c.costo ? 'Tesoro insufficiente' : '';
        let tg = M.tags(c.i, { una: true });
        if (c.mod) tg = tg.concat(M.tags(c.mod.eff).map(t => ({ t: t.t + ' (' + c.mod.turni + ' turni)', good: t.good })));
        return `<button class="choice" data-act="scegli" data-uid="${ev.uid}" data-idx="${i}" ${dis ? `disabled title="${dis}"` : ''}>
          <span class="ct">${c.t}</span><span class="cc">${c.costo ? it(c.costo) + ' mld' : 'gratis'}</span><span class="tags">${tagHtml(tg)}</span></button>`;
      }).join('');
      return `<article class="ev-card ${def.tipo}"><div class="ev-img">${MINIATURE[def.thumb]}</div>
        <div class="ev-body"><div class="ev-top"><h3>${def.titolo}</h3><span class="due ${rim <= 2 ? 'urgent' : ''}">scade tra ${rim} ${rim === 1 ? 'turno' : 'turni'}</span></div>
        <p>${def.testo}</p><div class="choices">${sc}</div>
        <div class="note">Se non decidi, sarà scelta: «${def.scelte[def.def].t}».</div></div></article>`;
    }).join('') || '<div class="note top">Nessun evento in attesa: il regno è tranquillo.</div>';
    const cron = s.registro.slice(0, 12).map(r => `<div class="cron ${r.tipo}"><b>${r.titolo}</b>${r.esito ? `<span>→ ${r.esito}</span>` : ''}<em>turno ${r.turno}</em></div>`).join('');
    return head('EVENTI', s.eventi.length ? `${s.eventi.length} in attesa di una decisione` : 'Tutto sotto controllo') + att + panel('Cronaca del regno', I().flag, cron);
  }

  window.Sezioni = { governo, parlamento, leggi, economia, societa, diplomazia, eventi };
})();
