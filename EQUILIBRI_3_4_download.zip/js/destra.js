// Pannello destro: il Re e il Consiglio del Governo
(function () {
  let uid = 0;

  function portrait(o) {
    const id = 'p' + (uid++);
    const hair = o.hair, skin = o.skin, shade = o.shade || '#00000022';
    let back = '', front = '';
    if (o.style === 'long') {
      back = `<path d="M24 52 C20 16 80 16 76 52 L80 100 L20 100Z" fill="${hair}"/>`;
      front = `<path d="M30 46 C32 24 68 24 70 46 C62 34 44 32 36 44 Z" fill="${hair}"/>`;
    } else if (o.style === 'bob') {
      back = `<path d="M26 56 C22 18 78 18 74 56 L72 70 L28 70Z" fill="${hair}"/>`;
      front = `<path d="M30 46 C30 22 70 22 70 46 C60 32 42 30 33 46Z" fill="${hair}"/>`;
    } else if (o.style === 'gray') {
      front = `<path d="M30 46 C26 20 74 20 70 46 C68 36 60 30 50 30 C40 30 32 36 30 46Z" fill="${hair}"/>`;
    } else {
      front = `<path d="M30 46 C28 22 72 22 70 46 C66 33 52 29 44 32 C36 34 32 38 30 46Z" fill="${hair}"/>`;
    }
    const beard = o.beard ? `<path d="M31 52 C32 74 42 78 50 78 C58 78 68 74 69 52 C66 62 60 64 50 64 C40 64 34 62 31 52Z" fill="${o.beard}"/>` : '';
    const lips = o.female ? '#b0405a' : '#8a4a3a';
    const extra = o.extra || '';
    return `<svg viewBox="0 0 100 120" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
      <defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${o.bg[0]}"/><stop offset="1" stop-color="${o.bg[1]}"/></linearGradient></defs>
      <rect width="100" height="120" fill="url(#${id})"/>
      ${back}
      <path d="M6 120 C6 90 30 82 50 82 C70 82 94 90 94 120Z" fill="${o.suit}"/>
      ${o.uniform ? `<path d="M30 92 L40 84 M70 92 L60 84" stroke="#e0b34a" stroke-width="2.5"/><circle cx="26" cy="100" r="2.2" fill="#e0b34a"/><circle cx="74" cy="100" r="2.2" fill="#e0b34a"/><rect x="62" y="96" width="10" height="4" fill="#c8312a"/>` : `<path d="M40 83 L50 102 L60 83Z" fill="#f4f1ea"/>${o.tie ? `<path d="M48 90 H52 L54 112 L50 116 L46 112Z" fill="${o.tie}"/>` : ''}`}
      <rect x="43" y="68" width="14" height="18" fill="${skin}"/><rect x="43" y="68" width="14" height="6" fill="${shade}"/>
      <ellipse cx="31" cy="52" rx="3.5" ry="5" fill="${skin}"/><ellipse cx="69" cy="52" rx="3.5" ry="5" fill="${skin}"/>
      <ellipse cx="50" cy="50" rx="19" ry="23" fill="${skin}"/>
      ${beard}${front}
      <path d="M38 45 Q42 42 46 45 M54 45 Q58 42 62 45" stroke="${o.brow || hair}" stroke-width="2" fill="none" stroke-linecap="round"/>
      <ellipse cx="42" cy="49" rx="2.4" ry="1.6" fill="#2a1a10"/><ellipse cx="58" cy="49" rx="2.4" ry="1.6" fill="#2a1a10"/>
      <path d="M50 50 L48 58 H52" stroke="${shade}" stroke-width="1.4" fill="none"/>
      <path d="M43 63 Q50 ${o.female ? 68 : 66} 57 63" stroke="${lips}" stroke-width="${o.female ? 2.6 : 2}" fill="none" stroke-linecap="round"/>
      ${extra}
    </svg>`;
  }

  const KING = `<svg viewBox="0 0 380 300" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="kbg" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#1a1208"/><stop offset=".55" stop-color="#6a4a22"/><stop offset="1" stop-color="#7a1414"/></linearGradient>
      <linearGradient id="kgold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0b0"/><stop offset=".5" stop-color="#e0b34a"/><stop offset="1" stop-color="#8a6420"/></linearGradient>
      <radialGradient id="klight" cx=".5" cy=".4" r=".6"><stop offset="0" stop-color="#ffd890" stop-opacity=".55"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient>
    </defs>
    <rect width="380" height="300" fill="url(#kbg)"/>
    <path d="M250 0 H380 V300 H300 C320 200 300 100 250 0Z" fill="#8a1a1a" opacity=".85"/>
    <path d="M270 0 C310 90 330 200 310 300" stroke="#5a0c0c" stroke-width="6" fill="none"/>
    <rect width="380" height="300" fill="url(#klight)"/>
    <!-- veste di ermellino -->
    <path d="M30 300 C40 230 110 205 190 205 C270 205 340 230 350 300Z" fill="#f4f1ea"/>
    <path d="M130 205 C150 240 230 240 250 205 C240 260 140 260 130 205Z" fill="#d8d2c4"/>
    ${[[70,262],[100,240],[300,262],[272,240],[60,290],[320,290],[96,276],[284,276],[132,258],[250,258]].map(([x,y])=>`<path d="M${x} ${y} l3 9 l3 -9 l-3 3z" fill="#1a1a1a"/>`).join('')}
    <!-- manto interno -->
    <path d="M140 205 L190 300 L240 205 C220 218 160 218 140 205Z" fill="#2a1a4a"/>
    <path d="M168 225 L190 300 L212 225" stroke="#e0b34a" stroke-width="3" fill="none"/>
    <circle cx="190" cy="232" r="7" fill="url(#kgold)" stroke="#6b4210"/>
    <!-- collo e volto -->
    <rect x="166" y="170" width="48" height="45" fill="#c98f6a"/>
    <path d="M166 195 Q190 215 214 195 V215 H166Z" fill="#a86f4c" opacity=".6"/>
    <ellipse cx="136" cy="130" rx="11" ry="17" fill="#c98f6a"/><ellipse cx="244" cy="130" rx="11" ry="17" fill="#c98f6a"/>
    <path d="M190 50 C145 50 132 90 138 130 C142 170 165 196 190 196 C215 196 238 170 242 130 C248 90 235 50 190 50Z" fill="#d9a07a"/>
    <path d="M138 130 C142 170 165 196 190 196 C215 196 238 170 242 130 C236 160 215 180 190 180 C165 180 144 160 138 130Z" fill="#c98f6a" opacity=".55"/>
    <!-- capelli e barba grigi -->
    <path d="M136 112 C130 70 150 52 190 52 C230 52 250 70 244 112 C240 90 228 78 212 74 C196 82 170 82 156 74 C146 80 138 92 136 112Z" fill="#cfcfcf"/>
    <path d="M142 136 C146 176 166 196 190 196 C214 196 234 176 238 136 C232 158 218 168 190 168 C162 168 148 158 142 136Z" fill="#d8d8d8"/>
    <path d="M168 170 Q190 182 212 170 Q190 160 168 170Z" fill="#e8e8e8"/>
    <!-- espressione -->
    <path d="M158 103 Q172 94 184 103 M196 103 Q208 94 222 103" stroke="#b0b0b0" stroke-width="5" fill="none" stroke-linecap="round"/>
    <ellipse cx="170" cy="115" rx="6" ry="3.8" fill="#fff"/><ellipse cx="210" cy="115" rx="6" ry="3.8" fill="#fff"/>
    <circle cx="172" cy="115" r="3" fill="#3a5a7a"/><circle cx="212" cy="115" r="3" fill="#3a5a7a"/>
    <path d="M190 118 L184 146 Q190 150 198 146" stroke="#b07a58" stroke-width="2.5" fill="none"/>
    <path d="M174 160 Q190 154 206 160" stroke="#8a5a40" stroke-width="3" fill="none" stroke-linecap="round"/>
    <path d="M150 128 q6 4 12 0 M218 128 q6 4 12 0" stroke="#a87a5a" stroke-width="1.5" fill="none"/>
    <!-- corona -->
    <path d="M142 62 L134 22 L160 40 L190 8 L220 40 L246 22 L238 62 Z" fill="url(#kgold)" stroke="#5c3f10" stroke-width="3" stroke-linejoin="round"/>
    <rect x="142" y="58" width="96" height="14" rx="3" fill="url(#kgold)" stroke="#5c3f10" stroke-width="3"/>
    <path d="M148 66 H232" stroke="#fff0b0" stroke-width="2" opacity=".7"/>
    <circle cx="190" cy="10" r="6" fill="#d33" stroke="#5c3f10"/><circle cx="134" cy="24" r="5" fill="#3a6fd3" stroke="#5c3f10"/><circle cx="246" cy="24" r="5" fill="#3a6fd3" stroke="#5c3f10"/>
    <circle cx="190" cy="66" r="5" fill="#3aa860" stroke="#5c3f10"/><circle cx="162" cy="66" r="3.5" fill="#d33"/><circle cx="218" cy="66" r="3.5" fill="#d33"/>
  </svg>`;

  const SHIELD = `<svg viewBox="0 0 60 70" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="sh1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe9a0"/><stop offset="1" stop-color="#8a6420"/></linearGradient></defs>
    <path d="M6 8 H54 V36 C54 52 42 62 30 67 C18 62 6 52 6 36Z" fill="url(#sh1)" stroke="#5c3f10" stroke-width="2"/>
    <path d="M11 13 H49 V36 C49 49 40 57 30 61 C20 57 11 49 11 36Z" fill="#c8312a"/>
    <path d="M30 22 C25 22 23 27 24 30 C21 29 19 32 21 35 C22 38 25 38 26 38 L24 47 L30 43 L36 47 L34 38 C35 38 38 38 39 35 C41 32 39 29 36 30 C37 27 35 22 30 22Z" fill="#f6c548" stroke="#6b4210"/>
    <path d="M18 8 L22 0 L26 6 L30 -2 L34 6 L38 0 L42 8Z" fill="url(#sh1)" stroke="#5c3f10"/></svg>`;

  const CONSIGLIO = [
    { nome: 'R. Venturi', ruolo: 'Presidente', p: { skin: '#d6a07c', shade: '#b07a58', hair: '#2a2420', style: 'short', suit: '#1c2a44', tie: '#7a1818', bg: ['#4a3a2a', '#1a1410'] } },
    { nome: 'E. Moretti', ruolo: 'Economia', p: { skin: '#d9a98a', shade: '#b8805e', hair: '#1a1210', style: 'long', female: true, suit: '#111', bg: ['#6a4a2a', '#2a1a10'], extra: '<circle cx="31" cy="60" r="1.8" fill="#e0b34a"/><circle cx="69" cy="60" r="1.8" fill="#e0b34a"/>' } },
    { nome: 'G. Rinaldi', ruolo: 'Difesa', p: { skin: '#d9a98a', shade: '#b8805e', hair: '#c8c8c8', style: 'gray', suit: '#1a2230', uniform: true, bg: ['#4a4a52', '#1a1a20'] } },
    { nome: 'G. Ferri', ruolo: 'Lavoro', p: { skin: '#f0c8a8', shade: '#d09a78', hair: '#e8c070', style: 'bob', female: true, suit: '#3a3a42', bg: ['#6a5a3a', '#241c10'] } },
    { nome: 'L. Bianchi', ruolo: 'Infrastrutture', p: { skin: '#c98f6a', shade: '#a86f4c', hair: '#1a1410', style: 'short', beard: '#2a1c14', suit: '#1c2430', tie: '#3a3a3a', bg: ['#5a4a38', '#1a140e'] } },
    { nome: 'S. Vitale', ruolo: 'Ambiente', p: { skin: '#d9a98a', shade: '#b8805e', hair: '#241812', style: 'long', female: true, suit: '#16241e', bg: ['#4a5a3a', '#141e10'] } }
  ];

  window.renderDestra = function (s) {
    const cards = CONSIGLIO.map((m, i) => { const slot=DATA.CONSIGLIO[i].id, assigned=(s.incarichi||{})[slot], actual=CONSIGLIO.find(x=>DATA.CONSIGLIO[CONSIGLIO.indexOf(x)]?.id===assigned)||m; return `<div class="min-card ${s.sezione === 'governo' && s.ui.ministro === slot ? 'sel' : ''}" data-go="governo" data-min="${slot}">
      <div class="pic">${portrait(assigned?(CONSIGLIO.find((x,j)=>DATA.CONSIGLIO[j].id===assigned)||m).p:m.p)}</div>
      <div class="plate"><b>${assigned?(CONSIGLIO.find((x,j)=>DATA.CONSIGLIO[j].id===assigned)||m).nome:'Vacante'}</b><span>${m.ruolo}</span></div></div>`; }).join('');
    return `
    <section class="king-card">
      <div class="king-pic">${KING}</div>
      <div class="king-plate">${SHIELD}<span>S.M. Re Adriano IV</span></div>
    </section>
    <section class="panel council">
      <header><svg viewBox="0 0 40 30"><g fill="#e0b34a" stroke="#8a6420"><circle cx="20" cy="9" r="6"/><path d="M8 28 C8 15 32 15 32 28Z"/><circle cx="7" cy="13" r="4.5"/><path d="M0 28 C0 19 14 19 14 28Z"/><circle cx="33" cy="13" r="4.5"/><path d="M26 28 C26 19 40 19 40 28Z"/></g></svg>Consiglio del Governo</header>
      <div class="council-grid">${cards}</div>
    </section>`;
  };

  window.Ritratto = portrait;
  window.RitrattoRe = KING;
  window.Ministri = CONSIGLIO.map((m, i) => Object.assign({ id: DATA.CONSIGLIO[i].id }, m));
  window.bindDestra = function () {};
})();
