// Icone SVG in stile fantasy (oro / verde)
window.Icons = {
  crest: `<svg viewBox="0 0 70 80" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="gg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe9a0"/><stop offset=".5" stop-color="#d9a73a"/><stop offset="1" stop-color="#8a6420"/></linearGradient>
      <linearGradient id="rr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e03a2a"/><stop offset="1" stop-color="#7a0f0a"/></linearGradient>
    </defs>
    <path d="M22 14 L26 4 L31 11 L35 2 L39 11 L44 4 L48 14 Z" fill="url(#gg)" stroke="#5c3f10" stroke-width="1.2"/>
    <circle cx="26" cy="5" r="2" fill="#d33"/><circle cx="35" cy="3" r="2" fill="#3a6fd3"/><circle cx="44" cy="5" r="2" fill="#d33"/>
    <rect x="22" y="13" width="26" height="5" rx="1" fill="url(#gg)" stroke="#5c3f10" stroke-width="1"/>
    <path d="M10 20 H60 V46 C60 62 47 72 35 77 C23 72 10 62 10 46 Z" fill="url(#gg)" stroke="#5c3f10" stroke-width="2"/>
    <path d="M15 25 H55 V46 C55 59 45 67 35 71 C25 67 15 59 15 46 Z" fill="url(#rr)" stroke="#3a0a05" stroke-width="1.5"/>
    <path d="M35 33 C30 33 27 37 28 41 C25 40 23 43 25 46 C26 49 29 49 30 49 L28 58 L35 54 L42 58 L40 49 C41 49 44 49 45 46 C47 43 45 40 42 41 C43 37 40 33 35 33 Z" fill="#f6c548" stroke="#6b4210" stroke-width="1"/>
    <circle cx="32" cy="41" r="1.2" fill="#3a0a05"/><circle cx="38" cy="41" r="1.2" fill="#3a0a05"/>
  </svg>`,

  flag: `<svg viewBox="0 0 60 40" xmlns="http://www.w3.org/2000/svg" style="width:56px;height:38px">
    <path d="M2 4 Q15 0 30 4 T58 4 V36 Q44 40 30 36 T2 36 Z" fill="#fff" stroke="#6b5420" stroke-width="1.5"/>
    <path d="M2 4 Q8 2 20 3 V37 Q8 38 2 36 Z" fill="#1f8a3c"/>
    <path d="M40 3 Q50 4 58 4 V36 Q48 38 40 37 Z" fill="#c8312a"/>
    <circle cx="30" cy="20" r="6" fill="#d9a73a" stroke="#6b4210"/>
  </svg>`,

  calendar: `<svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
    <rect x="3" y="7" width="34" height="30" rx="3" fill="#f1e3c0" stroke="#8a6420" stroke-width="2"/>
    <rect x="3" y="7" width="34" height="8" rx="3" fill="#b3261e"/>
    <rect x="10" y="3" width="3" height="8" rx="1" fill="#8a6420"/><rect x="27" y="3" width="3" height="8" rx="1" fill="#8a6420"/>
    ${[0,1,2,3,4].map(c=>[0,1,2].map(r=>`<rect x="${7+c*6}" y="${19+r*6}" width="4" height="4" fill="#5a3a12"/>`).join('')).join('')}
  </svg>`,

  chartUp: `<svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
    <rect x="5" y="24" width="6" height="12" fill="#3fbf5a"/><rect x="14" y="18" width="6" height="18" fill="#3fbf5a"/><rect x="23" y="12" width="6" height="24" fill="#3fbf5a"/>
    <path d="M4 22 L16 12 L24 16 L36 4" fill="none" stroke="#7bf092" stroke-width="3" stroke-linecap="round"/>
    <path d="M28 4 H36 V12" fill="none" stroke="#7bf092" stroke-width="3" stroke-linecap="round"/>
  </svg>`,

  coins: `<svg viewBox="0 0 44 40" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe9a0"/><stop offset="1" stop-color="#b8841f"/></linearGradient></defs>
    ${[30,24,18].map(y=>`<ellipse cx="14" cy="${y}" rx="12" ry="5" fill="url(#cg)" stroke="#6b4210"/>`).join('')}
    ${[34,28,22,16].map(y=>`<ellipse cx="30" cy="${y}" rx="12" ry="5" fill="url(#cg)" stroke="#6b4210"/>`).join('')}
  </svg>`,

  people: `<svg viewBox="0 0 48 40" xmlns="http://www.w3.org/2000/svg">
    <g fill="#f3dfb0" stroke="#8a6420" stroke-width="1">
      <circle cx="24" cy="12" r="6"/><path d="M12 36 C12 24 36 24 36 36 Z"/>
      <circle cx="9" cy="16" r="5"/><path d="M0 36 C0 26 18 26 18 36 Z"/>
      <circle cx="39" cy="16" r="5"/><path d="M30 36 C30 26 48 26 48 36 Z"/>
    </g>
  </svg>`,

  scales: `<svg viewBox="0 0 44 40" xmlns="http://www.w3.org/2000/svg">
    <g stroke="#e0b34a" stroke-width="2.5" fill="none" stroke-linecap="round">
      <path d="M22 5 V34"/><path d="M12 34 H32"/><path d="M6 11 H38"/>
      <path d="M6 11 L1 24 H11 Z"/><path d="M38 11 L33 24 H43 Z"/>
    </g>
    <circle cx="22" cy="5" r="3" fill="#e0b34a"/>
  </svg>`,

  question: `<svg viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg"><text x="15" y="23" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-size="24" font-weight="800" fill="#f5d98a">?</text></svg>`,

  gear: `<svg viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg">
    <path fill="#f5d98a" stroke="#8a6420" d="M13 2h4l1 4 3 1.5 3.5-2 3 3-2 3.5L27 14v4l-4 1-1.5 3 2 3.5-3 3-3.5-2L13 28H9l-1-4-3-1.5-3.5 2-3-3 2-3.5L1 18v-4l4-1 1.5-3-2-3.5 3-3 3.5 2z" transform="translate(1,0) scale(.95)"/>
    <circle cx="15" cy="15" r="5" fill="#0c2a22" stroke="#8a6420"/>
  </svg>`,

  // --- icone del menu ---
  home: `<svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 5 L2 21 H7 V35 H16 V25 H24 V35 H33 V21 H38 Z" fill="#fff3d0" stroke="#7a5412" stroke-width="2" stroke-linejoin="round"/>
    <rect x="17" y="25" width="6" height="10" fill="#7a5412"/>
  </svg>`,

  crown: `<svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="mg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe9a0"/><stop offset="1" stop-color="#b8841f"/></linearGradient></defs>
    <path d="M4 30 L2 11 L12 20 L20 6 L28 20 L38 11 L36 30 Z" fill="url(#mg)" stroke="#6b4210" stroke-width="1.8" stroke-linejoin="round"/>
    <rect x="4" y="30" width="32" height="6" rx="1.5" fill="url(#mg)" stroke="#6b4210" stroke-width="1.8"/>
    <circle cx="20" cy="6" r="2.5" fill="#d33"/><circle cx="2" cy="11" r="2" fill="#d33"/><circle cx="38" cy="11" r="2" fill="#d33"/>
  </svg>`,

  parliament: `<svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
    <g fill="#f0c860" stroke="#7a5412" stroke-width="1.5" stroke-linejoin="round">
      <path d="M20 3 L3 12 H37 Z"/>
      <rect x="4" y="12" width="32" height="3"/>
      <rect x="7" y="16" width="4" height="15"/><rect x="14" y="16" width="4" height="15"/><rect x="22" y="16" width="4" height="15"/><rect x="29" y="16" width="4" height="15"/>
      <rect x="3" y="31" width="34" height="3"/><rect x="1" y="34" width="38" height="3"/>
    </g>
  </svg>`,

  laws: `<svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
    <path d="M8 4 H30 Q34 4 34 8 V30 Q34 35 29 35 H12 Q7 35 7 30 Z" fill="#f1e3c0" stroke="#8a6420" stroke-width="2"/>
    <path d="M4 8 Q4 3 9 3 Q13 3 13 8" fill="none" stroke="#c9962f" stroke-width="3"/>
    <g stroke="#a8782a" stroke-width="2" stroke-linecap="round"><path d="M14 13 H29"/><path d="M14 19 H29"/><path d="M14 25 H25"/></g>
    <rect x="5" y="32" width="27" height="5" rx="2.5" fill="#d9a73a" stroke="#6b4210"/>
  </svg>`,

  economy: `<svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
    <rect x="3" y="24" width="7" height="13" fill="#f0c860" stroke="#7a5412" stroke-width="1.5"/>
    <rect x="13" y="17" width="7" height="20" fill="#f0c860" stroke="#7a5412" stroke-width="1.5"/>
    <rect x="23" y="11" width="7" height="26" fill="#f0c860" stroke="#7a5412" stroke-width="1.5"/>
    <path d="M3 18 L14 9 L22 13 L35 3" fill="none" stroke="#f6e7b0" stroke-width="3" stroke-linecap="round"/>
    <path d="M27 3 H35 V11" fill="none" stroke="#f6e7b0" stroke-width="3" stroke-linecap="round"/>
  </svg>`,

  society: `<svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
    <g fill="#f0c860" stroke="#7a5412" stroke-width="1.3">
      <circle cx="20" cy="11" r="6"/><path d="M8 34 C8 20 32 20 32 34 Z"/>
      <circle cx="7" cy="15" r="4.5"/><path d="M-1 34 C-1 24 14 24 14 34 Z"/>
      <circle cx="33" cy="15" r="4.5"/><path d="M26 34 C26 24 41 24 41 34 Z"/>
    </g>
  </svg>`,

  diplomacy: `<svg viewBox="0 0 44 40" xmlns="http://www.w3.org/2000/svg">
    <path d="M2 14 L14 10 L24 14 L32 12 L42 16 L36 30 L24 34 L12 30 Z" fill="#f6dfa0" stroke="#7a5412" stroke-width="2" stroke-linejoin="round"/>
    <path d="M14 10 L20 22 L30 20 L24 14" fill="#e0b34a" stroke="#7a5412" stroke-width="1.5"/>
    <path d="M12 30 L18 24 M24 34 L28 26" stroke="#7a5412" stroke-width="2"/>
  </svg>`,

  alert: `<svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="ag" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd966"/><stop offset="1" stop-color="#e0a020"/></linearGradient></defs>
    <path d="M20 3 L38 35 H2 Z" fill="url(#ag)" stroke="#7a5412" stroke-width="2" stroke-linejoin="round"/>
    <rect x="18" y="14" width="4" height="11" rx="1.5" fill="#2c1d0c"/><circle cx="20" cy="30" r="2.3" fill="#2c1d0c"/>
  </svg>`
};
