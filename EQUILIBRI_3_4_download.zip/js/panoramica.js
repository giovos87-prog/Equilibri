// Sezione Panoramica del Regno
(function () {
  const I = {
    up: `<svg viewBox="0 0 26 26"><path d="M13 2 L24 14 H17 V24 H9 V14 H2 Z" fill="#3fbf5a" stroke="#14582a" stroke-width="1.5" stroke-linejoin="round"/></svg>`,
    down: `<svg viewBox="0 0 26 26"><path d="M13 24 L2 12 H9 V2 H17 V12 H24 Z" fill="#d6403a" stroke="#7a1410" stroke-width="1.5" stroke-linejoin="round"/></svg>`,
    chart: `<svg viewBox="0 0 30 30"><rect x="3" y="17" width="5" height="10" fill="#e0b34a"/><rect x="11" y="11" width="5" height="16" fill="#e0b34a"/><rect x="19" y="6" width="5" height="21" fill="#e0b34a"/><path d="M3 12 L12 5 L18 8 L28 2" fill="none" stroke="#f5d98a" stroke-width="2.2" stroke-linecap="round"/></svg>`,
    flag: `<svg viewBox="0 0 30 30"><path d="M5 3 V28" stroke="#8a6420" stroke-width="2.5"/><path d="M5 4 Q14 0 18 5 T28 6 V16 Q20 20 16 15 T5 16 Z" fill="#e0b34a" stroke="#8a6420" stroke-width="1.5"/></svg>`,
    parl: `<svg viewBox="0 0 30 30"><g fill="#e0b34a" stroke="#8a6420"><path d="M15 2 L2 9 H28 Z"/><rect x="4" y="10" width="3.5" height="12"/><rect x="11" y="10" width="3.5" height="12"/><rect x="18" y="10" width="3.5" height="12"/><rect x="24" y="10" width="3" height="12"/><rect x="2" y="23" width="26" height="4"/></g></svg>`,
    target: `<svg viewBox="0 0 30 30"><circle cx="14" cy="16" r="12" fill="#f3e6c4" stroke="#8a6420" stroke-width="2"/><circle cx="14" cy="16" r="8" fill="#c8312a"/><circle cx="14" cy="16" r="4.5" fill="#f3e6c4"/><circle cx="14" cy="16" r="2" fill="#c8312a"/><path d="M14 16 L27 3" stroke="#e0b34a" stroke-width="2.5"/><path d="M22 2 L28 2 L28 8" fill="none" stroke="#e0b34a" stroke-width="2.5"/></svg>`,
    people: `<svg viewBox="0 0 24 24"><g fill="#a01c15"><circle cx="12" cy="7" r="4"/><path d="M4 21 C4 11 20 11 20 21 Z"/></g></svg>`,
    check: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#2f9a4c" stroke="#14582a" stroke-width="2"/><path d="M6.5 12.5 L10.5 16.5 L17.5 8" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    checkGold: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#e0b34a" stroke="#8a6420" stroke-width="2"/><path d="M6.5 12.5 L10.5 16.5 L17.5 8" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
    crownBig: `<svg viewBox="0 0 74 52"><defs><linearGradient id="pg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe9a0"/><stop offset="1" stop-color="#b8841f"/></linearGradient></defs><path d="M8 40 L4 14 L22 28 L37 6 L52 28 L70 14 L66 40 Z" fill="url(#pg)" stroke="#5c3f10" stroke-width="2.5" stroke-linejoin="round"/><rect x="8" y="40" width="58" height="9" rx="2" fill="url(#pg)" stroke="#5c3f10" stroke-width="2.5"/><circle cx="37" cy="6" r="4" fill="#d33"/><circle cx="4" cy="14" r="3.5" fill="#3a6fd3"/><circle cx="70" cy="14" r="3.5" fill="#3a6fd3"/><circle cx="37" cy="44" r="2.5" fill="#d33"/></svg>`,
    // tessere
    tPil: `<svg viewBox="0 0 50 50"><rect x="6" y="30" width="8" height="14" fill="#7bf092" stroke="#14582a" stroke-width="1.5"/><rect x="17" y="22" width="8" height="22" fill="#7bf092" stroke="#14582a" stroke-width="1.5"/><rect x="28" y="14" width="8" height="30" fill="#7bf092" stroke="#14582a" stroke-width="1.5"/><path d="M5 26 L19 14 L28 19 L44 5" fill="none" stroke="#eaffee" stroke-width="3.5" stroke-linecap="round"/><path d="M35 5 H44 V14" fill="none" stroke="#eaffee" stroke-width="3.5" stroke-linecap="round"/></svg>`,
    tTesoro: `<svg viewBox="0 0 50 50"><defs><linearGradient id="tg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe9a0"/><stop offset="1" stop-color="#b8841f"/></linearGradient></defs>${[40,34,28,22].map(y=>`<ellipse cx="17" cy="${y}" rx="13" ry="5.5" fill="url(#tg)" stroke="#6b4210"/>`).join('')}${[44,38,32,26,20].map(y=>`<ellipse cx="34" cy="${y}" rx="13" ry="5.5" fill="url(#tg)" stroke="#6b4210"/>`).join('')}</svg>`,
    tDebito: `<svg viewBox="0 0 50 50"><defs><linearGradient id="dg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff8a80"/><stop offset="1" stop-color="#b3261e"/></linearGradient></defs>${[40,34,28,22].map(y=>`<ellipse cx="17" cy="${y}" rx="13" ry="5.5" fill="url(#dg)" stroke="#5a0f0f"/>`).join('')}${[44,38,32,26,20].map(y=>`<ellipse cx="34" cy="${y}" rx="13" ry="5.5" fill="url(#dg)" stroke="#5a0f0f"/>`).join('')}</svg>`,
    tLavoro: `<svg viewBox="0 0 50 50"><g fill="#f3e6ff" stroke="#321a5e" stroke-width="1.5"><circle cx="25" cy="14" r="7"/><path d="M11 42 C11 26 39 26 39 42 Z"/><circle cx="9" cy="20" r="5.5"/><path d="M0 42 C0 30 17 30 17 42 Z"/><circle cx="41" cy="20" r="5.5"/><path d="M33 42 C33 30 50 30 50 42 Z"/></g></svg>`,
    tInfl: `<svg viewBox="0 0 50 50"><path d="M14 22 L22 8 M36 22 L28 8" stroke="#f3e6c4" stroke-width="3.5" stroke-linecap="round"/><path d="M4 22 H46 L40 44 H10 Z" fill="#e6f0ff" stroke="#0e2f5e" stroke-width="2" stroke-linejoin="round"/><path d="M16 28 V38 M25 28 V38 M34 28 V38" stroke="#1f5fa8" stroke-width="3" stroke-linecap="round"/></svg>`
  };

  const SCENE = `<svg class="scene" viewBox="0 0 1012 150" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="bsk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6fa8d6"/><stop offset=".7" stop-color="#cfe5ee"/><stop offset="1" stop-color="#f6e9c4"/></linearGradient></defs>
    <rect width="1012" height="150" fill="url(#bsk)"/>
    <ellipse cx="260" cy="30" rx="90" ry="14" fill="#fff" opacity=".7"/><ellipse cx="760" cy="22" rx="110" ry="12" fill="#fff" opacity=".6"/>
    <path d="M520 150 L610 52 L670 92 L760 30 L860 96 L930 56 L1012 100 V150 Z" fill="#7a95a8"/>
    <path d="M520 150 L610 52 L640 74 L590 150Z M760 30 L790 62 L740 60Z M930 56 L950 76 L915 72Z" fill="#fff" opacity=".7"/>
    <path d="M0 150 V95 Q150 70 300 100 T560 110 T820 108 T1012 118 V150 Z" fill="#4d8a52"/>
    <path d="M0 150 V118 Q200 100 400 124 T800 126 T1012 134 V150 Z" fill="#2f6b35"/>
    <path d="M60 130 Q150 70 290 92 L330 130 Z" fill="#5a8a42"/>
    <g stroke="#7a6a48" fill="#eee3c8">
      <rect x="150" y="56" width="110" height="44"/><rect x="138" y="30" width="26" height="70"/><rect x="246" y="38" width="26" height="62"/><rect x="190" y="38" width="40" height="30"/>
    </g>
    <g fill="#a8452c"><path d="M134 30 L151 4 L168 30Z"/><path d="M242 38 L259 14 L276 38Z"/><path d="M186 38 L210 14 L234 38Z"/></g>
    <g fill="#5a3a1a"><rect x="205" y="78" width="10" height="22"/><rect x="146" y="50" width="6" height="10"/><rect x="254" y="54" width="6" height="10"/></g>
    <g>${[0,1,2,3,4,5,6,7].map(i=>`<rect x="${320+i*42}" y="${112+(i%3)*4}" width="30" height="20" fill="#f1dfae" stroke="#8a6a3a"/><path d="M${316+i*42} ${112+(i%3)*4} L${335+i*42} ${98+(i%3)*4} L${354+i*42} ${112+(i%3)*4}Z" fill="${i%2?'#b3492d':'#c8683a'}" stroke="#7a3a20"/>`).join('')}</g>
    ${[20,60,690,1000,960].map((x,i)=>`<circle cx="${x}" cy="${128+(i%2)*6}" r="16" fill="#2f6b35"/><circle cx="${x+7}" cy="${121+(i%2)*6}" r="11" fill="#3f8a45"/>`).join('')}
  </svg>`;

  const THUMBS = {
    proteste: `<svg viewBox="0 0 130 46" preserveAspectRatio="xMidYMid slice"><rect width="130" height="46" fill="#4a4a5a"/><rect y="0" width="130" height="16" fill="#8a96b0"/>${[0,1,2,3,4,5,6,7,8].map(i=>`<circle cx="${8+i*14}" cy="${26+(i%3)*3}" r="6" fill="${['#d6a07a','#c58a62','#e8bd96'][i%3]}"/><path d="M${i*14} 46 Q${8+i*14} ${30+(i%3)*3} ${16+i*14} 46Z" fill="${['#8a2a2a','#2a3a6a','#3a3a3a'][i%3]}"/>`).join('')}<rect x="60" y="4" width="34" height="14" fill="#f1e3c0" stroke="#5a3a12"/><path d="M76 18 V30" stroke="#5a3a12" stroke-width="2"/></svg>`,
    accordo: `<svg viewBox="0 0 130 46" preserveAspectRatio="xMidYMid slice"><rect width="130" height="46" fill="#6a82a0"/><rect y="30" width="130" height="16" fill="#8a9bb0"/><path d="M0 46 L30 18 L55 28 L75 28 L100 18 L130 46Z" fill="#2a3a5a"/><path d="M48 30 L65 22 L82 30 L65 40Z" fill="#f0d0b0" stroke="#7a5a3a"/><path d="M52 30 H78" stroke="#7a5a3a"/></svg>`,
    legge: `<svg viewBox="0 0 130 46" preserveAspectRatio="xMidYMid slice"><rect width="130" height="46" fill="#8a5a2a"/><rect x="0" y="30" width="130" height="16" fill="#5a3416"/><path d="M26 34 L40 8 H96 L108 34Z" fill="#f3e6c4" stroke="#5a3a12"/><path d="M48 16 H90 M46 22 H92 M44 28 H94" stroke="#a8884a" stroke-width="2"/><path d="M96 10 L122 2 L112 18Z" fill="#fff" stroke="#8a7a5a"/><circle cx="104" cy="30" r="6" fill="#b3261e"/></svg>`
  };

  const ICON_BY_TYPE = { neg: I.people, pos: I.check, neu: I.checkGold };

  function hemicycle(parti, totale) {
    const rows = 6, r0 = 70, rStep = 17, cx = 170, cy = 165;
    const radii = Array.from({ length: rows }, (_, i) => r0 + i * rStep);
    const sumR = radii.reduce((a, b) => a + b, 0);
    let counts = radii.map(r => Math.round(totale * r / sumR));
    let diff = totale - counts.reduce((a, b) => a + b, 0);
    for (let i = rows - 1; diff !== 0; i = (i - 1 + rows) % rows) { counts[i] += Math.sign(diff); diff -= Math.sign(diff); }
    const seats = [];
    radii.forEach((r, ri) => {
      for (let k = 0; k < counts[ri]; k++) {
        const a = Math.PI - (Math.PI * (k + 0.5)) / counts[ri];
        seats.push({ a, x: cx + r * Math.cos(a), y: cy - r * Math.sin(a) });
      }
    });
    seats.sort((p, q) => q.a - p.a);
    let idx = 0;
    const dots = [];
    parti.forEach(p => { for (let k = 0; k < p.seggi; k++) { const s = seats[idx++]; if (s) dots.push(`<circle cx="${s.x.toFixed(1)}" cy="${s.y.toFixed(1)}" r="5.6" fill="${p.colore}" stroke="rgba(0,0,0,.35)" stroke-width=".8"/>`); } });
    return `<svg viewBox="0 0 340 175" xmlns="http://www.w3.org/2000/svg">${dots.join('')}</svg>`;
  }

  window.renderPanoramica = function (s) {
    const P = s.parlamento;
    const governo = P.partiti.filter(p => p.governo).reduce((a, p) => a + p.seggi, 0);
    const soglia = Math.floor(P.totale / 2) + 1;
    const stato = governo >= soglia + 10 ? ['Governo stabile', ''] : governo >= soglia ? ['Maggioranza risicata', 'warn'] : ['Governo in minoranza', 'bad'];
    const sg = (n, d = 1) => (n >= 0 ? '+' : '−') + Math.abs(n).toFixed(d).replace('.', ',');
    const cons = n => Math.round(n);

    const tiles = [
      ['pil', I.tPil, 'PIL', `${sg(s.pil)}% ${s.pil >= 0 ? '▲' : '▼'}`],
      ['tesoro', I.tTesoro, 'Tesoro', `${s.tesoro.toFixed(1).replace('.', ',')} mld €`],
      ['debito', I.tDebito, 'Debito', `${s.debito.toFixed(1).replace('.', ',')}%`],
      ['lavoro', I.tLavoro, 'Lavoro', `${s.lavoro.toFixed(1).replace('.', ',')}%`],
      ['inflazione', I.tInfl, 'Inflazione', `${s.inflazione.toFixed(1).replace('.', ',')}%`]
    ].map(([c, ic, t, v]) => `<div class="stat-tile ${c}">${ic}<div><div class="t">${t}</div><div class="v">${v}</div></div></div>`).join('');

    const U = s.ultimo;
    const evoRows = [
      { nome: 'PIL', delta: U.dPil, unita: '%', scala: 1, buono: U.dPil >= 0 },
      { nome: 'Disoccupazione', delta: U.dDis, unita: ' p.p.', scala: 1, buono: U.dDis <= 0 },
      { nome: 'Consenso', delta: U.dCons, unita: ' p.p.', scala: 3, buono: U.dCons >= 0 }
    ];
    const evo = evoRows.map(e => {
      const good = e.buono;
      const w = Math.max(4, Math.min(100, Math.abs(e.delta) / e.scala * 100));
      return `<div class="evo-row ${good ? 'up' : 'down'}">${e.delta >= 0 ? I.up : I.down}<span class="name">${e.nome}</span>
        <div class="bar ${good ? 'g' : 'r'}"><i style="width:${w}%"></i></div><span class="val">${sg(e.delta)}${e.unita}</span></div>`;
    }).join('');

    const eventi = s.registro.slice(0, 3).map(e => `<div class="ev-item ${e.tipo}" data-go="eventi">
      <div class="thumb">${MINIATURE[e.thumb]}</div><div class="txt">${ICON_BY_TYPE[e.tipo]}<span>${e.titolo}</span></div><span class="chev">›</span></div>`).join('');

    const prio = Motore.prioritaView(s).map(p => `<div class="prio ${p.fatto ? 'done' : ''} ${p.focus ? 'focus' : ''}" data-go="${p.sez}"><div class="box"></div><span>${p.titolo}</span></div>`).join('')
      || '<div class="prio"><span>Nessuna priorità: il regno è tranquillo.</span></div>';

    return `
    <div class="pan-banner">${SCENE}
      <div class="pan-ribbon">${I.crownBig.replace('<svg', '<svg class="crown"')}
        <div class="plate"><h1>PANORAMICA DEL REGNO</h1></div>
        <div class="sub">Settimana ${s.settimana} di ${DATA.MESI[s.mese]} ${s.anno}</div>
      </div>
    </div>
    <div class="stat-row">${tiles}</div>
    <div class="pan-grid">
      <section class="panel"><header>${I.chart}Evoluzione del turno</header><div class="body">${evo}</div></section>
      <section class="panel"><header>${I.flag}Eventi principali</header><div class="body">${eventi}</div></section>
      <section class="panel"><header>${I.parl}Maggioranza parlamentare</header>
        <div class="parl">${hemicycle(P.partiti, P.totale)}<div class="seats">${governo} / ${P.totale}</div>
        <div class="stable ${stato[1]}">${stato[1] === '' ? I.check : ''}${stato[0]}</div></div></section>
      <section class="panel"><header>${I.target}Priorità del turno</header><div class="body"><div class="prio-list">${prio}</div></div></section>
    </div>`;
  };

  window.Emiciclo = hemicycle;
  window.Icone = I;
  window.bindPanoramica = function () {};
})();
