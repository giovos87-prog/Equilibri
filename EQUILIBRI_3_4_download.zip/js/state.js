// Stato globale del gioco Equilibri 3.3
(function () {
  const SAVE_KEY = 'equilibri26-salvataggio';

  function iniziale() {
    return {
      regno: 'Regno di Valdoria',
      anno: 2033, mese: 4, settimana: 3,
      turno: 52, turniTotali: 208,
      pil: 0.4, tesoro: 18.9, debito: 71.8, lavoro: 92.6, inflazione: 2.1,
      consenso: 54, stabilita: 68,
      budget: { tasse: 33, sociale: 50, infra: 50, sicurezza: 50 },
      indici: { sanita: 62, istruzione: 58, ambiente: 55, sicurezza: 60 },
      gruppi: { lav: 55, imp: 52, gio: 50, anz: 57 },
      parlamento: {
        totale: 200,
        partiti: [
          { id: 'verdi', nome: 'Verdi', seggi: 62, colore: '#1f9a3c', governo: true },
          { id: 'blu', nome: 'Blu', seggi: 60, colore: '#1f5fd0', governo: true },
          { id: 'rossi', nome: 'Rossi', seggi: 48, colore: '#d0302a', governo: false },
          { id: 'gialli', nome: 'Gialli', seggi: 22, colore: '#f0c820', governo: false },
          { id: 'ind', nome: 'Indipendenti', seggi: 8, colore: '#b8b8b8', governo: false }
        ]
      },
      politica: { fiducia: { verdi: 68, blu: 68 }, richieste: [], opposizione: { pressione: 0, iniziative: 0, ultimaIniziativa: 0, ultimaProposta: null }, crisi: null, mozione: null, ultimaMozione: 0, storico: [], storicoMozioni: [], crisiGoverno: null },
      incarichi: { venturi:'venturi', moretti:'moretti', rinaldi:'rinaldi', ferri:'ferri', bianchi:'bianchi', vitale:'vitale' },
      programma: { accordi: [], ultimaTrattativa: 0 },
      sondaggi: { governo: 54, partiti: {verdi:31,blu:30,rossi:24,gialli:11,ind:4}, ultimaRilevazione:52, storico:[] },
      leadership: { verdi: {fiducia:70,tensione:20}, blu: {fiducia:68,tensione:22} },
      campagna: { ultima:0, bonus:{verdi:0,blu:0,rossi:0,gialli:0,ind:0}, storico:[] },
      ministri: { fiducia: {venturi:72,moretti:66,rinaldi:70,ferri:74,bianchi:68,vitale:76}, scandalo:null, dimissioni:[], storicoScandali:[] },
      leggi: { inVigore: ['energia'], inDiscussione: [], bloccate: {}, storicoVoti: [] },
      eventi: [
        { uid: 1, id: 'proteste', nato: 51, scade: 57 },
        { uid: 2, id: 'siccita', nato: 51, scade: 57 }
      ],
      uidNext: 3,
      ultimoEvento: {},
      mods: [],
      dir: {},
      diplomazia: {},
      registro: [
        { turno: 51, titolo: 'Proteste trasporti', tipo: 'neg', thumb: 'proteste' },
        { turno: 50, titolo: 'Accordo commerciale', tipo: 'pos', thumb: 'accordo' },
        { turno: 49, titolo: 'Legge energia approvata', tipo: 'neu', thumb: 'legge' }
      ],
      priorita: [
        { id: 'fiscale', fattoDa: null },
        { id: 'infra', fattoDa: null },
        { id: 'proteste', fattoDa: null }
      ],
      ultimo: { dPil: 0.4, dDis: -0.3, dCons: 2 },
      storia: [],
      fine: null,
      negStreak: 0,
      rng: 20330521
    };
  }

  const State = {
    listeners: [],
    sezione: 'panoramica',
    ui: { leggiTab: 'catalogo', leggiCat: 'Tutte', modal: null },
    subscribe(fn) { this.listeners.push(fn); },
    emit() { this.listeners.forEach(fn => fn(this)); },
    set(patch) { Object.assign(this, patch); this.emit(); },

    nuova(silenzioso) {
      const n = iniziale();
      n.diplomazia = {};
      DATA.NAZIONI.forEach(x => { n.diplomazia[x.id] = { rel: x.rel, accordo: x.accordo, patto: x.patto, ultima: -99 }; });
      for (let i = 0; i < 24; i++) {
        n.storia.push({ t: 28 + i, pil: 0.3 + 0.1 * Math.sin(i / 3), infl: 2.1, lav: 92.2 + i * 0.016, tes: 17 + i * 0.08, deb: 72.5 - i * 0.03, cons: 52 + i * 0.08 });
      }
      Object.assign(this, n);
      this.sezione = 'panoramica';
      this.ui = { leggiTab: 'catalogo', leggiCat: 'Tutte', modal: null };
      if (!silenzioso) this.emit();
    },

    chiavi() { return Object.keys(iniziale()); },

    salva() {
      try {
        const o = {};
        this.chiavi().forEach(k => { o[k] = this[k]; });
        localStorage.setItem(SAVE_KEY, JSON.stringify(o));
      } catch (e) { /* storage non disponibile */ }
    },

    carica() {
      try {
        const raw = localStorage.getItem(SAVE_KEY);
        if (!raw) return false;
        const o = JSON.parse(raw);
        if (!o || o.turno == null) return false;
        Object.assign(this, o);
        this.politica=this.politica||{fiducia:{verdi:68,blu:68},richieste:[],opposizione:{pressione:0,iniziative:0,ultimaIniziativa:0},crisi:null,storico:[]};
        this.politica.opposizione=Object.assign({pressione:0,iniziative:0,ultimaIniziativa:0,ultimaProposta:null},this.politica.opposizione||{});
        if(this.politica.mozione===undefined)this.politica.mozione=null;
        if(this.politica.ultimaMozione===undefined)this.politica.ultimaMozione=0;
        if(!Array.isArray(this.politica.storicoMozioni))this.politica.storicoMozioni=[];
        if(this.politica.crisiGoverno===undefined)this.politica.crisiGoverno=null;
        this.incarichi=Object.assign({venturi:'venturi',moretti:'moretti',rinaldi:'rinaldi',ferri:'ferri',bianchi:'bianchi',vitale:'vitale'},this.incarichi||{});
        this.programma=this.programma||{accordi:[],ultimaTrattativa:0};
        this.programma.accordi=Array.isArray(this.programma.accordi)?this.programma.accordi:[];
        this.programma.ultimaTrattativa=Number(this.programma.ultimaTrattativa||0);
        this.sondaggi=this.sondaggi||{governo:54,partiti:{verdi:31,blu:30,rossi:24,gialli:11,ind:4},ultimaRilevazione:this.turno||52,storico:[]};
        this.sondaggi.partiti=Object.assign({verdi:31,blu:30,rossi:24,gialli:11,ind:4},this.sondaggi.partiti||{});
        this.sondaggi.storico=Array.isArray(this.sondaggi.storico)?this.sondaggi.storico:[];
        this.leadership=this.leadership||{verdi:{fiducia:70,tensione:20},blu:{fiducia:68,tensione:22}};
        ['verdi','blu'].forEach(id=>this.leadership[id]=Object.assign({fiducia:68,tensione:20},this.leadership[id]||{}));
        this.campagna=this.campagna||{ultima:0,bonus:{},storico:[]};
        this.campagna.bonus=Object.assign({verdi:0,blu:0,rossi:0,gialli:0,ind:0},this.campagna.bonus||{});
        this.campagna.storico=Array.isArray(this.campagna.storico)?this.campagna.storico:[];
        this.ministri=this.ministri||{fiducia:{venturi:72,moretti:66,rinaldi:70,ferri:74,bianchi:68,vitale:76},scandalo:null,dimissioni:[]};
        this.ministri.fiducia=Object.assign({venturi:72,moretti:66,rinaldi:70,ferri:74,bianchi:68,vitale:76},this.ministri.fiducia||{});
        if(!Array.isArray(this.ministri.dimissioni))this.ministri.dimissioni=[];
        if(!Array.isArray(this.ministri.storicoScandali))this.ministri.storicoScandali=[];
        this.leggi=this.leggi||{inVigore:[],inDiscussione:[],bloccate:{},storicoVoti:[]};
        this.leggi.inDiscussione=(this.leggi.inDiscussione||[]).map(d=>Object.assign({fase:'commissione',avanzamento:0,emendamento:null,camera:null,senato:null,bonus:0},d));
        return true;
      } catch (e) { return false; }
    },

    cancellaSalvataggio() { try { localStorage.removeItem(SAVE_KEY); } catch (e) { /* ok */ } }
  };

  window.State = State;
})();
