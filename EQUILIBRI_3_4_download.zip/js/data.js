// Dati statici del gioco: partiti, leggi, eventi, nazioni, direttive
window.DATA = (function () {
  // assi ideologici: [spesa/redistribuzione, sociale, ambiente, ordine]
  const PARTITI = [
    { id: 'verdi', nome: 'Verdi', colore: '#1f9a3c', ideol: [0.3, 0.5, 0.9, -0.2] },
    { id: 'blu', nome: 'Blu', colore: '#1f5fd0', ideol: [-0.7, -0.1, -0.3, 0.4] },
    { id: 'rossi', nome: 'Rossi', colore: '#d0302a', ideol: [0.8, 0.8, 0.3, -0.3] },
    { id: 'gialli', nome: 'Gialli', colore: '#f0c820', ideol: [-0.1, 0.2, -0.3, 0.8] },
    { id: 'ind', nome: 'Indipendenti', colore: '#b8b8b8', ideol: [0, 0, 0, 0] }
  ];

  const G = (lav, imp, gio, anz) => ({ lav, imp, gio, anz });

  // eff = effetti permanenti finché la legge è in vigore (spostano gli obiettivi degli indicatori)
  const LEGGI = [
    { id: 'energia', nome: 'Legge sull\'energia', cat: 'Ambiente', costo: 3, axes: [0.3, 0.1, 0.5, 0], desc: 'Riordina il mercato energetico e frena i rincari.', eff: { infl: -0.1, amb: 4 } },
    { id: 'riforma-fiscale', nome: 'Riforma fiscale', cat: 'Fisco', costo: 1.2, axes: [0.3, 0.2, 0, 0], desc: 'Semplifica il sistema delle imposte e le rende più eque.', eff: { pil: 0.12, tes: 0.03, stab: 1, gr: G(2, 3, 0, 0) } },
    { id: 'infrastrutture', nome: 'Piano infrastrutture', cat: 'Economia', costo: 4, axes: [0.4, 0, -0.2, 0.2], desc: 'Strade, ponti e ferrovie: cantieri in tutto il regno.', eff: { pil: 0.15, lav: 0.6, tes: -0.04, stab: 1, gr: G(2, 2, 0, 0) } },
    { id: 'sanita', nome: 'Rafforzamento sanitario', cat: 'Sociale', costo: 3, axes: [0.7, 0.6, 0, 0], desc: 'Più medici, più ospedali, liste d\'attesa più corte.', eff: { san: 10, tes: -0.07, stab: 1, gr: G(2, 0, 0, 6) } },
    { id: 'scuola', nome: 'Riforma della scuola', cat: 'Sociale', costo: 2.5, axes: [0.4, 0.5, 0, 0], desc: 'Investe su docenti, edifici e formazione tecnica.', eff: { ist: 10, pil: 0.05, tes: -0.04, gr: G(0, 0, 6, 0) } },
    { id: 'transizione', nome: 'Transizione verde', cat: 'Ambiente', costo: 5, axes: [0.3, 0.1, 0.9, -0.1], desc: 'Rinnovabili, reti e incentivi per l\'industria pulita.', eff: { amb: 12, pil: 0.06, infl: -0.1, tes: -0.05, gr: G(0, -2, 4, 0) } },
    { id: 'incentivi-lavoro', nome: 'Incentivi all\'assunzione', cat: 'Lavoro', costo: 1.5, axes: [0.1, 0.3, -0.1, 0], desc: 'Sgravi alle imprese che assumono giovani e disoccupati.', eff: { lav: 1.2, pil: 0.05, tes: -0.05, gr: G(4, 3, 0, 0) } },
    { id: 'salario-minimo', nome: 'Salario minimo', cat: 'Lavoro', costo: 0.5, axes: [0.6, 0.7, 0, -0.1], desc: 'Una paga di base garantita per legge.', eff: { lav: -0.4, infl: 0.15, tes: 0.01, gr: G(7, -6, 0, 0) } },
    { id: 'taglio-imprese', nome: 'Taglio fiscale alle imprese', cat: 'Fisco', costo: 1, axes: [-0.8, -0.3, -0.2, 0], desc: 'Meno tasse sugli utili per attrarre investimenti.', eff: { pil: 0.15, tes: -0.08, infl: 0.05, gr: G(-2, 8, 0, 0) } },
    { id: 'patrimoni', nome: 'Imposta sui grandi patrimoni', cat: 'Fisco', costo: 0.3, axes: [0.9, 0.6, 0, -0.1], desc: 'Un contributo dalle grandi ricchezze per finanziare lo Stato.', eff: { tes: 0.1, pil: -0.08, gr: G(4, -7, 0, 0) } },
    { id: 'pensioni', nome: 'Riforma delle pensioni', cat: 'Sociale', costo: 0.5, axes: [-0.4, -0.6, 0, 0.2], desc: 'Allunga l\'età di uscita e libera risorse per i giovani.', eff: { tes: 0.09, stab: -2, gr: G(0, 0, 4, -9) } },
    { id: 'sicurezza', nome: 'Pacchetto sicurezza', cat: 'Sicurezza', costo: 1.5, axes: [0, -0.4, 0, 0.9], desc: 'Più pattuglie, più controlli, tribunali più rapidi.', eff: { sic: 12, stab: 2, tes: -0.03, gr: G(0, 0, -3, 3) } },
    { id: 'giustizia', nome: 'Riforma della giustizia', cat: 'Istituzioni', costo: 1, axes: [0, 0, 0, 0.3], desc: 'Processi più veloci e meno cause arretrate.', eff: { stab: 4, pil: 0.04, gr: G(0, 2, 0, 0) } },
    { id: 'digitale', nome: 'Agenda digitale', cat: 'Economia', costo: 2, axes: [0.1, 0.1, 0.1, 0], desc: 'Servizi pubblici online e banda larga ovunque.', eff: { pil: 0.12, lav: -0.2, tes: 0.02, gr: G(0, 4, 3, 0) } },
    { id: 'difesa', nome: 'Potenziamento della difesa', cat: 'Sicurezza', costo: 3.5, axes: [-0.2, -0.5, -0.4, 0.9], desc: 'Nuovi mezzi e addestramento per l\'esercito del Re.', eff: { stab: 3, tes: -0.06, pil: 0.03, gr: G(-1, 0, 0, 0) } },
    { id: 'calmieri', nome: 'Calmieri sui prezzi', cat: 'Economia', costo: 0.4, axes: [0.5, 0.3, 0, 0], desc: 'Tetti ai prezzi dei beni essenziali.', eff: { infl: -0.45, pil: -0.1, tes: -0.02, gr: G(3, -4, 0, 3) } },
    { id: 'bonus-famiglie', nome: 'Bonus famiglie', cat: 'Sociale', costo: 2, axes: [0.5, 0.5, 0, -0.1], desc: 'Un assegno mensile per le famiglie con figli.', eff: { infl: 0.1, tes: -0.05, gr: G(4, 0, 3, 3) } },
    { id: 'riforma-pa', nome: 'Riforma dell\'amministrazione', cat: 'Istituzioni', costo: 1.5, axes: [-0.2, -0.2, 0, 0.2], desc: 'Meno burocrazia e uffici più efficienti.', eff: { tes: 0.06, stab: 1, gr: G(-2, 3, 0, 0) } },
    { id: 'parchi', nome: 'Parchi e tutela ambientale', cat: 'Ambiente', costo: 1.2, axes: [0.1, 0.2, 1, -0.2], desc: 'Aree protette, bonifiche e foreste del regno.', eff: { amb: 10, pil: -0.04, gr: G(0, -2, 4, 0) } }
  ];

  const ACCORDO_EFF = { pil: 0.05, tes: 0.025 };
  const PATTO_EFF = { stab: 1.5, tes: -0.02 };

  const NAZIONI = [
    { id: 'marenna', nome: 'Marenna', desc: 'Potenza marinara e primo partner commerciale.', rel: 68, accordo: true, patto: false, col: ['#1f5fa8', '#f3e6c4'] },
    { id: 'karvia', nome: 'Karvia', desc: 'Vicino a nord, rivale storico per i confini.', rel: 38, accordo: false, patto: false, col: ['#7a1410', '#222'] },
    { id: 'isolde', nome: 'Isolde', desc: 'Regno neutrale, ricco di università e banche.', rel: 55, accordo: false, patto: false, col: ['#2f7a4a', '#f3e6c4'] },
    { id: 'tessaly', nome: 'Tessaly', desc: 'Produce energia e materie prime.', rel: 60, accordo: false, patto: false, col: ['#c98a1f', '#3a2a10'] },
    { id: 'drovia', nome: 'Drovia', desc: 'Stato instabile oltre i monti: rischi e opportunità.', rel: 45, accordo: false, patto: false, col: ['#6a3aa8', '#f3e6c4'] }
  ];

  const CONSIGLIO = [
    { id: 'venturi', comp: 70, dir: { nome: 'Discorso alla nazione', desc: 'Il Presidente parla al paese e rassicura.', costo: 0, cd: 8, i: { stab: 2, gr: G(1, 1, 1, 1) } } },
    { id: 'moretti', comp: 82, dir: { nome: 'Stretta sulla spesa', desc: 'Tagli rapidi: più cassa ora, meno gradimento.', costo: 0, cd: 8, i: { tes: 0.5, gr: G(-2, 0, 0, -2) } } },
    { id: 'rinaldi', comp: 65, dir: { nome: 'Esercitazioni congiunte', desc: 'Mostra la forza dell\'esercito e rafforza l\'ordine.', costo: 0.3, cd: 6, i: { stab: 2.5, idx: { sicurezza: 3 } } } },
    { id: 'ferri', comp: 74, dir: { nome: 'Tavolo con le parti sociali', desc: 'Sindacati e imprese si siedono allo stesso tavolo.', costo: 0.2, cd: 6, i: { lav: 0.2, gr: G(3, 2, 0, 0) } } },
    { id: 'bianchi', comp: 68, dir: { nome: 'Cantieri rapidi', desc: 'Accelera le opere: più lavoro per qualche settimana.', costo: 0.5, cd: 8, mod: { turni: 6, nome: 'Cantieri rapidi', eff: { pil: 0.12, lav: 0.3 } } } },
    { id: 'vitale', comp: 77, dir: { nome: 'Campagna verde', desc: 'Iniziative ambientali che piacciono ai giovani.', costo: 0.3, cd: 6, i: { idx: { ambiente: 5 }, gr: G(0, 0, 3, 0) } } }
  ];

  // eventi: i = effetti immediati, mod = effetti temporanei
  const E = (t, i, extra) => Object.assign({ t, i: i || {} }, extra || {});
  const EVENTI = [
    { id: 'proteste', titolo: 'Proteste trasporti', tipo: 'neg', thumb: 'proteste', testo: 'Treni e autobus fermi in tutto il regno: i lavoratori dei trasporti chiedono salari più alti e la fine dei tagli.', peso: s => 0.15, def: 2,
      scelte: [E('Aprire il dialogo con i sindacati', { stab: 2, gr: G(3, 0, 0, 0) }, { costo: 0.8 }), E('Imporre il servizio minimo', { stab: -2, gr: G(-5, 0, -3, 0) }), E('Ignorare le proteste', { stab: -4 }, { mod: { turni: 6, nome: 'Trasporti paralizzati', eff: { pil: -0.1 } } })] },
    { id: 'siccita', titolo: 'Crisi dell\'acqua nelle campagne', tipo: 'neg', thumb: 'natura', testo: 'Le piogge mancano da mesi. I raccolti sono a rischio e i contadini chiedono aiuto.', peso: s => 0.2 + (s.indici.ambiente < 50 ? 0.2 : 0), def: 2,
      scelte: [E('Finanziare nuovi bacini', { gr: G(0, 2, 0, 0), idx: { ambiente: 2 } }, { costo: 1.5 }), E('Razionare l\'acqua', { stab: -1, gr: G(-2, -2, 0, -2) }), E('Lasciar fare al mercato', { gr: G(-3, 0, 0, 0) }, { mod: { turni: 8, nome: 'Raccolti scarsi', eff: { pil: -0.08, infl: 0.2 } } })] },
    { id: 'scandalo', titolo: 'Scandalo al ministero', tipo: 'neg', thumb: 'scandalo', testo: 'Un quotidiano rivela favori ad amici di un alto funzionario. L\'opinione pubblica pretende chiarezza.', peso: s => 0.15 + (s.stabilita < 55 ? 0.1 : 0), def: 1,
      scelte: [E('Licenziare il funzionario e aprire un\'inchiesta', { stab: 1, gr: G(2, 0, 2, 2) }, { costo: 0.2 }), E('Difenderlo pubblicamente', { stab: -3, gr: G(-3, 0, -4, -3) })] },
    { id: 'export', titolo: 'Boom delle esportazioni', tipo: 'pos', thumb: 'economia', testo: 'I prodotti del regno vanno a ruba all\'estero. Le fabbriche lavorano a pieno ritmo.', peso: s => 0.18 + (s.pil < 0.3 ? 0.05 : 0), def: 0,
      scelte: [E('Reinvestire nelle imprese', { gr: G(2, 3, 0, 0) }, { mod: { turni: 8, nome: 'Boom export', eff: { pil: 0.18, lav: 0.4 } } }), E('Incassare subito le entrate', { tes: 1.5 }, { mod: { turni: 4, nome: 'Boom export', eff: { pil: 0.1 } } })] },
    { id: 'energia-rincari', titolo: 'Rincari dell\'energia', tipo: 'neg', thumb: 'economia', testo: 'Il prezzo di gas e carbone sale in fretta. Le bollette pesano su famiglie e imprese.', peso: s => 0.18 + (s.indici.ambiente < 50 ? 0.05 : 0), def: 2,
      scelte: [E('Sussidiare le bollette', { gr: G(3, 2, 0, 3) }, { costo: 1.2 }), E('Chiedere moderazione ai fornitori', { infl: 0.1, gr: G(0, 0, 0, 0) }), E('Lasciare che il mercato si aggiusti', { infl: 0.4, gr: G(-3, -3, 0, -3) })] },
    { id: 'sciopero', titolo: 'Sciopero generale', tipo: 'neg', thumb: 'proteste', testo: 'Il paese si ferma: scuole, uffici e fabbriche chiusi. Le piazze chiedono un cambio di rotta.', peso: s => (s.consenso < 46 ? 0.5 : s.consenso < 52 ? 0.08 : 0), def: 2,
      scelte: [E('Concedere un tavolo negoziale', { stab: 2, gr: G(4, -2, 0, 0) }, { costo: 1 }), E('Mostrare fermezza', { stab: -3, gr: G(-6, 2, -3, 0) }), E('Aspettare che passi', { stab: -5 }, { mod: { turni: 5, nome: 'Paese paralizzato', eff: { pil: -0.15 } } })] },
    { id: 'banca', titolo: 'Crisi di una grande banca', tipo: 'neg', thumb: 'economia', testo: 'Una banca del regno è sull\'orlo del fallimento. I risparmiatori sono nel panico.', peso: s => (s.debito > 80 ? 0.35 : 0.05), def: 2,
      scelte: [E('Salvarla con denaro pubblico', { stab: 2 }, { costo: 3 }), E('Lasciarla fallire', { stab: -3, gr: G(-3, -5, 0, -4) }, { mod: { turni: 8, nome: 'Credito frenato', eff: { pil: -0.15 } } })] },
    { id: 'epidemia', titolo: 'Epidemia stagionale', tipo: 'neg', thumb: 'salute', testo: 'Un virus influenzale intenso mette a dura prova gli ospedali.', peso: s => 0.1 + (s.indici.sanita < 58 ? 0.3 : 0), def: 1,
      scelte: [E('Potenziare i reparti e vaccinare', { idx: { sanita: 3 }, gr: G(0, 0, 0, 3) }, { costo: 1 }), E('Affidarsi ai medici di base', { gr: G(-1, 0, 0, -4) }, { mod: { turni: 5, nome: 'Epidemia', eff: { pil: -0.08, lav: -0.3 } } })] },
    { id: 'confine', titolo: 'Tensione al confine', tipo: 'neg', thumb: 'militare', testo: 'Pattuglie di Karvia sconfinano di nuovo. L\'esercito è in allerta.', peso: s => (s.diplomazia.karvia.rel < 45 ? 0.35 : 0.04), def: 2,
      scelte: [E('Inviare un ambasciatore', { stab: 1 }, { costo: 0.2, rel: ['karvia', 8] }), E('Schierare truppe al confine', { stab: 2, gr: G(0, 0, -1, 2) }, { costo: 0.8, rel: ['karvia', -8] }), E('Non reagire', { stab: -3 }, { rel: ['karvia', -4] })] },
    { id: 'festa', titolo: 'Festa del Regno', tipo: 'pos', thumb: 'festa', testo: 'Il Re invita il popolo alle celebrazioni nazionali. Fuochi d\'artificio in ogni città.', peso: s => 0.15, def: 0,
      scelte: [E('Organizzare grandi festeggiamenti', { stab: 2, gr: G(3, 2, 3, 3) }, { costo: 0.6 }), E('Celebrare con sobrietà', { gr: G(1, 0, 1, 2) })] },
    { id: 'giacimento', titolo: 'Scoperto un giacimento', tipo: 'pos', thumb: 'economia', testo: 'I geologi trovano un ricco giacimento di minerali nel nord del regno.', peso: s => 0.04, def: 0,
      scelte: [E('Affidarlo allo Stato', { tes: 4 }, { mod: { turni: 20, nome: 'Miniere statali', eff: { tes: 0.05 } } }), E('Metterlo all\'asta alle imprese', { tes: 2, gr: G(0, 5, 0, 0) }, { mod: { turni: 20, nome: 'Miniere private', eff: { pil: 0.08, lav: 0.2 } } })] },
    { id: 'rivolta-fiscale', titolo: 'Rivolta fiscale', tipo: 'neg', thumb: 'proteste', testo: 'Commercianti e artigiani scendono in piazza: le tasse sono troppo alte.', peso: s => (s.budget.tasse > 38 ? 0.4 : 0), def: 1,
      scelte: [E('Promettere un alleggerimento', { stab: 1, gr: G(2, 3, 0, 0) }), E('Tenere duro', { stab: -3, gr: G(-2, -5, 0, 0) })] },
    { id: 'cyber', titolo: 'Attacco informatico', tipo: 'neg', thumb: 'militare', testo: 'Hacker stranieri paralizzano i sistemi di alcuni uffici pubblici.', peso: s => 0.08, def: 1,
      scelte: [E('Investire in sicurezza digitale', { stab: 1, idx: { sicurezza: 2 } }, { costo: 1 }), E('Ripristinare e aspettare', { stab: -1 }, { mod: { turni: 4, nome: 'Servizi in tilt', eff: { pil: -0.08 } } })] },
    { id: 'alluvione', titolo: 'Alluvione sulle coste', tipo: 'neg', thumb: 'natura', testo: 'Piogge torrenziali allagano villaggi e campi. Servono soccorsi immediati.', peso: s => 0.07 + (s.indici.ambiente < 50 ? 0.25 : 0), def: 1,
      scelte: [E('Soccorsi e ricostruzione immediata', { stab: 1, gr: G(2, 0, 0, 2) }, { costo: 2 }), E('Aiuti minimi', { stab: -2, gr: G(-3, -2, 0, -3) }, { mod: { turni: 6, nome: 'Zone alluvionate', eff: { pil: -0.1 } } })] },
    { id: 'fuga-cervelli', titolo: 'Fuga dei giovani talenti', tipo: 'neg', thumb: 'economia', testo: 'Laureati e tecnici partono all\'estero: qui mancano scuole e prospettive.', peso: s => (s.indici.istruzione < 50 ? 0.3 : 0.03), def: 1,
      scelte: [E('Borse di studio e incentivi al ritorno', { gr: G(0, 0, 4, 0) }, { costo: 1 }), E('Lasciar correre', { gr: G(0, -2, -4, 0) }, { mod: { turni: 8, nome: 'Fuga dei talenti', eff: { pil: -0.06 } } })] },
    { id: 'turisti', titolo: 'Ondata di turisti', tipo: 'pos', thumb: 'festa', testo: 'Il bel tempo e la fama dei castelli portano visitatori da ogni dove.', peso: s => 0.14, def: 0,
      scelte: [E('Promuovere il turismo', { gr: G(2, 3, 0, 0) }, { costo: 0.4, mod: { turni: 6, nome: 'Alta stagione', eff: { pil: 0.14, lav: 0.4 } } }), E('Lasciare il flusso naturale', {}, { mod: { turni: 4, nome: 'Alta stagione', eff: { pil: 0.07 } } })] },
    { id: 'accordo-offerta', titolo: 'Offerta di un patto di amicizia', tipo: 'neu', thumb: 'accordo', testo: 'Un\'ambasciata straniera propone un trattato di amicizia che migliorerebbe i rapporti.', peso: s => 0.09, def: 1,
      scelte: [E('Accettare con entusiasmo', { stab: 1 }, { relMin: 6 }), E('Declinare con cortesia', {})] }
  ];
  // l'evento «accordo-offerta» migliora la relazione con la nazione meno cordiale tra le neutrali

  const MESI = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
  const GRUPPI = { lav: 'Lavoratori', imp: 'Imprese', gio: 'Giovani', anz: 'Anziani' };

  return {
    PARTITI, LEGGI, EVENTI, NAZIONI, CONSIGLIO, MESI, GRUPPI, ACCORDO_EFF, PATTO_EFF, G,
    legge: id => LEGGI.find(l => l.id === id),
    evento: id => EVENTI.find(e => e.id === id),
    partito: id => PARTITI.find(p => p.id === id),
    ministro: id => CONSIGLIO.find(m => m.id === id)
  };
})();
